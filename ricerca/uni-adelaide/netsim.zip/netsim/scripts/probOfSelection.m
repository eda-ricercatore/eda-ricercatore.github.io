% This is written by Zhiyang Ong to the probability of selection

x=0.6;
y=x - 4*x^2 + 6*x^3 - 4*x^4 + x^5
y1=x - 5*x^2 + 10*x^3 - 10*x^4 + 5*x^5 - x^6
y2=x - 6*x^2 + 15*x^3 - 20*x^4 + 15*x^5 - 6*x^6 + x^7
p4=x*(1-x)^3
p5=x*(1-x)^4
p6=x*(1-x)^5
p7=x*(1-x)^6