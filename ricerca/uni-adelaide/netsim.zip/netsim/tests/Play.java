public class Play {
	public static void main(String[] args) {
		int[] a = new int[5];
		if(a[4]==0) {
			System.out.println("Hello World"+16%4);
		}
	}
}