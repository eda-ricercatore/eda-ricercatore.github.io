/**
 * An implementation of a content-addressable memory (CAM) at
 * electronic system-level (ESL).
 * 
 * Copyright	(C)	<2010>	<Zhiyang Ong>
 * @author Zhiyang Ong
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *
 *
 * 
 * This is the output buffer.
 * Input	: read 32-bit data of selected word in CAM
 *			: MATCH signal
 *			: system clock
 * Output	: read data of selected word in CAM (after 1 clock cycle)
 *			: MATCH signal (after 1 clock cycle)
 * Function	: Receive inputs at the positive-edge of the clock.
 *			  
 *			  Transfer the data from the input ports to the output
 *			  ports after half a period.
 */

// ==================================================================

// Include header files...
//#include "systemc.h"
#include "opbuffer.h"

/**
 * Function to transfer data from the inputs to the outputs.
 * After the hold time for the input registers, transfer the data to
 * the output after half a period. This is because the hold time would
 * be less than half a period.
 * @param - None
 * @return - Nothing
 */
void opbuffer::transfer_data() {
	/**
	 * Wait for 0.5 clock cycle - to meet setup and hold time
	 * requirements
	 */
	wait(buf_clk->period()/2, SC_NS);
	// Transfer the inputs to the outputs
	out_match = in_match;
	op_rd_data = in_rd_data;
}