/**
 * An implementation of a content-addressable memory (CAM) at
 * electronic system-level (ESL).
 * 
 * Copyright	(C)	<2010>	<Zhiyang Ong>
 * @author Zhiyang Ong
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *
 *
 * 
 * This is an input buffer for the CAM.
 * Input	: input word ("9-bit encoded" virtual address)
 *			: comparand (32-bit pattern)
 *			: data (32-bit address) to be written into the CAM array
 *			: command to indicate that data should be written into the
 *			  CAM array
 *			: command to indicate that data should be read from the
 *			  CAM array
 *			: system clock
 * Output	: input word (after 1 clock cycle)
 *			: comperand (after 1 clock cycle)
 *			: write data (after 1 clock cycle)
 *			: write command (after 1 clock cycle)
 *			: read command (after 1 clock cycle)
 * Function	: receive inputs at the positive-edge of the clock and
 *			  transfer the inputs to the outputs after 1 clock cycle
 */

// ==================================================================

// Include header files...
//#include "systemc.h"
#include "ip_buffer.h"

/**
 * Function to transfer data from the inputs to the outputs.
 * After the hold time for the input registers, transfer the data to
 * the output after half a period. This is because the hold time would
 * be less than half a period.
 * @param - None
 * @return - Nothing
 */
//void ip_buffer::send_data() {
void send_data() {
	// Read and write operations cannot be carried out at the same time.
	assert(ip_wr_cmd != ip_rd_cmd);
	
	/**
	 * Wait for 0.5 clock cycle - to meet setup and hold time
	 * requirements
	 */
	wait(buf_clk->period()/2, SC_NS);
	// Transfer the inputs to the outputs
	op_word = ip_word;
	op_cpd = ip_cpd;
	op_wr_data = ip_wr_data;
	op_wr_cmd = ip_wr_cmd;
	op_rd_cmd = ip_rd_cmd;
}
