/**
 * An implementation of a content-addressable memory (CAM) at
 * electronic system-level (ESL).
 * 
 * Copyright	(C)	<2010>	<Zhiyang Ong>
 * @author Zhiyang Ong
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *
 *
 * 
 * This is an input buffer for the CAM.
 * Input	: input word ("9-bit encoded" virtual address)
 *			: comparand (32-bit pattern)
 *			: data (32-bit address) to be written into the CAM array
 *			: command to indicate that data should be written into the
 *			  CAM array
 *			: command to indicate that data should be read from the
 *			  CAM array
 *			: system clock
 * Output	: input word (after 1 clock cycle)
 *			: comperand (after 1 clock cycle)
 *			: write data (after 1 clock cycle)
 *			: write command (after 1 clock cycle)
 *			: read command (after 1 clock cycle)
 * Function	: receive inputs at the positive-edge of the clock and
 *			  transfer the inputs to the outputs after 1 clock cycle
 */

// ==================================================================
//#include "systemc.h"
SC_MODULE(ipbuffer) {
	// Declaring inputs and outputs
	
	// Set the dimension of the length variable to 32
	//sc_length_param length_arr(32);
	// Set the length of the bit-vectors and arrays to 32
	//sc_length_context bv_len(length_arr);
	
	
	// Input port.
	// Input "encoded" CAM address
	sc_in<sc_uint<9> > ip_word;
	// Input comperand
	sc_in<sc_bv<32> > ip_cpd;
	// Input write data
	sc_in<sc_bv<32> > ip_wr_data;
	// Input write command
	sc_in<bool> ip_wr_cmd;
	// Input read command
	sc_in<bool> ip_rd_cmd;
	// Input clock
	sc_in_clk buf_clk;
	
	
	// Output port.
	// Output word ("9-bit encoded" virtual address)
	sc_out<sc_uint<9> > op_word;
	// Output comperand
	sc_out<sc_bv<32> > op_cpd;
	// Output write data
	sc_out<sc_bv<32> > op_wr_data;
	// Output write command
	sc_out<bool> op_wr_cmd;
	// Output read command
	sc_out<bool> op_rd_cmd;
	
	
	// "Constants"
	// Clock period (of 20 ns).
	
	
	// Declaring instance variables...
	
	
	// --------------------------------------------------------------
	
	
	// Declaring functions...
	// Function to transfer data from the inputs to the outputs.
	void send_data();
	
	// --------------------------------------------------------------
	
	// Constructor 
	SC_CTOR(ipbuffer) {
		// Method Process
		//SC_THREAD(send_data, buf_clk.pos());
		SC_THREAD(send_data);
		// Sensitivity list of the method process
		sensitive_pos << buf_clk;
		sensitive << ip_word;
		sensitive << ip_cpd;
		sensitive << ip_wr_data;
		sensitive << ip_wr_cmd;
		sensitive << ip_rd_cmd;
	}
};
