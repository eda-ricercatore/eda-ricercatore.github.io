/**
 * An implementation of a content-addressable memory (CAM) at
 * electronic system-level (ESL).
 * 
 * Copyright	(C)	<2010>	<Zhiyang Ong>
 * @author Zhiyang Ong
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *
 *
 * 
 * This is an input buffer for the address decoder.
 * Input	: 5-bit encoded virtual address
 *			: comparand
 *			: system clock
 * Output	: word; 32-bit virtual address (after 1 clock cycle)
 *			: 32-bit comperand (after 1 clock cycle)
 * Function	: receive inputs at the positive-edge of the clock, decode
 *			  the virtual address, and transfer the decoded virtual
 *			  address and the comperand to the outputs after 1 clock
 *			  cycle
 */

// ==================================================================

// Include header files...
#include "addrdecoder.h"


/**
 * Function to decode the 5-bit encoded virtual address into a 32-bit
 * word, and pass the word and the comperand to the output ports.
 * @param - None
 * @return - Nothing
 */
void addrdecoder::decode_input() {
	/**
	 * Wait for 0.5 clock cycle - to meet setup and hold time
	 * requirements
	 */
	wait(ad_clk->period()/2, SC_NS);
	// Transfer the inputs to the outputs
	op_word = ip_word;
	op_cpd = ip_cpd;
	op_wr_data = ip_wr_data;
	op_wr_cmd = ip_wr_cmd;
	op_rd_cmd = ip_rd_cmd;
}

