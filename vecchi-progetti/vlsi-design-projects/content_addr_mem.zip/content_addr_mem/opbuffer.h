/**
 * An implementation of a content-addressable memory (CAM) at
 * electronic system-level (ESL).
 * 
 * Copyright	(C)	<2010>	<Zhiyang Ong>
 * @author Zhiyang Ong
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *
 *
 * 
 * This is the output buffer.
 * Input	: read 32-bit data of selected word in CAM
 *			: MATCH signal
 *			: system clock
 * Output	: read data of selected word in CAM (after 1 clock cycle)
 *			: MATCH signal (after 1 clock cycle)
 * Function	: Receive inputs at the positive-edge of the clock.
 *			  
 *			  Transfer the data from the input ports to the output
 *			  ports after half a period.
 */

// ==================================================================

//#include "systemc.h"
SC_MODULE(opbuffer) {
	// Declaring inputs and outputs
	
	// Input port.
	// Input read data
	sc_in<sc_lv<32> > ip_rd_data;
	// Input match signal
	sc_in<bool> in_match;
	// Input clock
	sc_in_clk op_clk;
	
	
	// Output port.
	// Output read data
	sc_out<sc_lv<32> > op_rd_data;
	// Output MATCH signal
	sc_out<bool> out_match;
	
	
	// "Constants"
	
	
	// Declaring instance variables...
	
	
	// --------------------------------------------------------------
	
	
	// Declaring functions...
	// Function to transfer data from the inputs to the outputs
	void transfer_data();
	
	// --------------------------------------------------------------
	
	// Constructor 
	SC_CTOR(opbuffer) {
		// Method Process
		SC_CTHREAD(transfer_data, op_clk.pos());
		// Sensitivity list of the method process
		sensitive_pos(op_clk);
	}
};
