/**
 * An implementation of a content-addressable memory (CAM) at
 * electronic system-level (ESL).
 * 
 * Copyright	(C)	<2010>	<Zhiyang Ong>
 * @author Zhiyang Ong
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *
 *
 * 
 *
 * Specifications of the (positive-edge triggered) CAM:
 * TLB CAM (512-word CAM memory):
 *		Input:	word (e.g. 32-bit virtual address)
 *		Output:	(9+1)-bits [or 10-bits] indicating which of the 2^9
 *				row(s)/word(s) in the CAM match with the input word
 *		Fn:		Match input data with data words in the memory array.
 *				If match exists between input data and data word in
 *				memory, set MATCH [signal/flag] to TRUE.
 *				Else, keep MATCH at FALSE.
 *				Assert corresponding matchline(s) for row(s)/word(s)
 *				that match the virtual address.
 *				The asserted "matchline can serve as the wordline to
 *				access a RAM containing the associated physical
 *				address".
 *
 *				512 = 2^9
 *
 *		Modules	: input buffer
 *				: 5-to-32 address decoder -- use a bit-vector to
 *				  represent the comparand register (passed along
 *				  without being processed in the decoder, so that it
 *				  remains in sync with the input word (address) when
 *				  they are transfered to the CAM array).
 *				: 512-word CAM array -- use bit-vectors to represent
 *				  validity block and mask register.
 *				  The comparand register holds the pattern based on
 *				  the first 12 most significant bits of the word.
 *				: output buffer
 *
 *		Interfaces	: between input buffer and address decoder
 *					: between address decoder and CAM array
 *					: between CAM array and output buffer
 *					
 *
 *		Channels	: bus between input buffer and address decoder
 *		(primitive)	: bus between address decoder and CAM array
 *					: between CAM array and output buffer
 *					: MATCH signal between CAM array and output
 *					  buffer
 *					: bit-vector array (to contain words in CAM array)
 *					: timer (clock controlling the CAM)
 *		Events	: Perform data transfer operations between module A
 *				  and B at the positive edge of the clock
 *				: use SC_CTHREAD
 *
 *		Other notes:
 *		1)	Use absolute and integer-valued model of time in
 *			SystemC 2.0.
 *		2)	Use cycle-based simulation for CAM using detailed clock
 *			cycle accurate RTL models, and untimed and high-level
 *			functional model.
 *		3)	Create and instantiate clock in the main method.
 *		4)	Define I/O ports for each module: input, output, or
 *			bidirectional.
 *		5)	Determine which SystemC communication protocol(s) shall
 *			I use, and if I would model the communication of modules
 *			between different levels for abstraction.
 *		6)	Use SystemC classes (turn their compilation flag(s) on)
 *			for run-time error checking to support debugging.
 *		7)	Use SystemC waveform tracing support to create VCD dumps.
 *		8)	The design of the address decoder module should implement
 *			the decoding of a 9-bit input to a 512-bit output to
 *			select the designated word to replace its contents.
 *			However, this would require the implementation of a large
 *			switch statement, and the subsequent conversion of a
 *			bit-vector into an integer to select the designated word
 *			in an array of bit-vectors.
 *			Hence, I decided to pass the "encoded" and "decoded"
 *			addresses as integers, without redundant conversions
 *			between the integer data type and the bit-vector data
 *			type.
 *
 * 
 *
 *
 *
 * [Notes from my reading about content-addressable memory (CAM).]
 *
 * From [Rabaey 2003, pp. 626], "content-addressable memories (CAM)
 * [or associative memories] form [a] class of nonrandom access 
 * memories".
 * Input of CAM:	a word of data [that would be processed in query-
 *					style format]
 * Output of CAM:	
 * Function of CAM:	Match input data with data words in the memory
 *					array.
 *					If match exists between input data and data word
 *					in memory, set MATCH [signal/flag] to TRUE.
 *					Else, keep MATCH at FALSE.
 *					
 * [Rabaey 2003, pp. 627]
 * Reference memory architectures as N-word memories, where each word
 * is M bits wide.
 *
 * [Rabaey 2003, pp. 629]
 * Memory core: Array of 4096 * 2048 cells = Each of the 4096 rows store 256
 * 8-bit words. Row address is represented by 12 bits, and column 
 * address is 8-bit wide.
 *
 * [Rabaey 2003, pp. 632]
 * "512-word CAM memory, which supports three modes of operation: read,
 * write, and match."
 * "The match mode is unique to associative memories."
 * Match simultaneously compare all the rows/elements of the CAM array
 * to determine if the [64-bit] word in each row matches with the
 * [pattern found in the] comparand. The mask is used to determine the
 * columns to look at during the comparison.
 * Fig. 12-7 represents the microarchitecture for 512-word CAM array.
 * The control logic issues commands to the I/O buffer to fetch input
 * data and output data.
 * The I/O buffers connects the CAM array to other memory structures
 * in the VLSI system, relays input to the comparand, and receives 
 * data from the control logic.
 * The comparand block contains the input data pattern to match.
 * The mask stores a word with bits set to HIGH, if their corresponding
 * bits in the comparand are set to HIGH.
 * The validity block has a bit for each row/word in the CAM array.
 * If a row/word in the CAM array matches the pattern stored in the
 * comparand, the corresponding bit representing this row/word in the
 * validity block is set. The validity block contains 512 (2^9) 
 * validity bits.
 * The priority encoder stores information about the rows/words that
 * match the pattern stored in the comparand. It obtains this
 * information from the validity block. If there exists multiple rows/
 * words that match the pattern, the priority encoder uses the addresses
 * of these rows/words in the CAM array to break the tie. The priority
 * encoder selects the row/word "with the highest address, and encodes
 * it in binary." Here, "the highest address typically corresponds to
 * the latest entry in that cache, and this is the most desirable 
 * match". The output of the priority encoder has 10 (9 + 1) bits, since
 * 9 bits are used to encode 512 (= 2^9) rows/words in the CAM array
 * and an additional "match found" bit to indicate if no match is found.
 * [This last sentence is found in pp. 632-633.]
 *
 * [Rabaey 2003, pp. 672]
 * Fig. 12-40 shows how a CAM array can be integrated with an on-chip
 * cache memory. Note that the address decoder found in Fig. 12-7 is 
 * located outside the CAM array in Fig. 12-40. Also, the input drivers
 * to the CAM array (in Fig. 12-40) can be part of the input (or I/O)
 * buffers found in Fig. 12-7. The hit logic in Fig. 12-40 can be the
 * connected to the priority encoder in Fig. 12-7.
 *
 * [Rabaey 2003, pp. 670]
 * A CAM array can concurrently compare all its rows/words with the 
 * pattern found in the comparand because of the transistor-level
 * circuit design of the CAM array. A CAM array is made up of a two-
 * dimensional array of 9-transistor CAM cells. It is the connection
 * (or structure) of the CAM cells in the CAM array that allows this
 * simultaneous comparison to occur. However, the behavioral modeling
 * and simulation of the CAM array would have difficulty modeling the
 * concurrent comparison of all the rows/words (in the CAM array).
 * CAM arrays are known not to be very power efficient.
 *
 * [Rabaey 2003, pp. 671]
 * Concerning the application of a CAM array with a SRAM array in an
 * on-chip cache memory in Fig. 12-40, the cache replacement policy
 * is used to displace an entry in a full cache. A cache hit occurs
 * when the input address to the cache/CAM is found to be a match in
 * the CAM, and the data in that address in the SRAM is read off the
 * cache. Else, a cache miss occurs, and the data must be read off a
 * lower-level cache or system/physical memory.
 *
 * Either Fig. 12-40 on [Rabaey 2003, pp. 672] or Fig. 12-7 on [Rabaey
 * 2003, pp. 632] would make a good project.
 * 
 * [Weste 2005, pp. 747]
 * A content-addressable memory (CAM) has an additional operation
 * compared to an SRAM, which performs only the read and write
 * operations. This additional operation is matching. 
 * "Matching asserts a matchline output for each word of the CAM that
 * contains a specified key".
 * "A common application of CAMs is translation lookaside buffers
 * (TLBs) in microprocessors supporting virtual memory".
 * There exists 10-transistor (10T) and 9-transistor (9T)
 * implementations of CAM cells.
 *
 * [Weste 2005, pp. 747]
 * TLB CAM:
 *		Input:	virtual address
 *		Output:	(n+1)-bits indicating which of the 2^n row(s)/word(s)
 *				in the CAM match with the virtual address
 *		Fn:		Assert corresponding matchline(s) for row(s)/word(s)
 *				that match the virtual address.
 *				The asserted "matchline can serve as the wordline to
 *				access a RAM containing the associated physical
 *				address".
 *
 * Fig. 11.52 on [Weste 2005, pp. 749] is similar to Fig. 12-40 on
 * [Rabaey 2003, pp. 672].
 *
 *
 *
 * [Patterson 2009, pp. 471]
 * A content addressable memory (CAM) is a circuit that performs
 * comparison and storage. It allows cache designers to implement
 * cache with higher set associativity using CAMs than with SRAMs
 * and comparators.
 * In 2008, cache implementations of 8-way (and above) set associativity
 * use CAMs, rather than SRAMs and comparators.
 *
 * [Patterson 2009, pp. 481]
 * Common page sizes are 4 KB, 16 KB, 32 KB, or 64 KB.
 *
 * 
 *
 * 
 *
 * 
 * 
 *
 *
 * 
 *
 *
 *
 * [Notes from my reading about networks-on-chip (NoCs).]
 *
 * [Weste 2005, pp. 380]
 * Examples for interconnect structures that connect/join different
 * modules in an integrated circuit include on-chip busses, mesh
 * interconnect structures, and Networks-on-a-Chip (NoCs).
 * 
 * [Weste 2005, pp. 487]
 * Consider on-chip interconnections as communication channels between
 * modules that should "transmit data within a 'quality-service'
 * setting", and "constraints on throughput, latency, and correctness".
 * This is preferred to considering them as point-to-point wires, since
 * this would require the implementation of a protocol stack that
 * "isolates and orthogonalizes the various functionality, performance,
 * and reliability concerns".
 * 
 * [Weste 2005, pp. 487-488]
 * Instead of using "statically wired source-to-destination"
 * connections, transfer data between modules as packets in a "network
 * of wires, switches, and routers", and allow this network to
 * dynamically determine "how and when to route these packets through
 * its segments".
 * 
 * See http://cva.stanford.edu/billd_webpage_new.html
 * 
 *
 *
 *
 * 
 *
 *
 *
 * References:
 * [Patterson 2009]
 * David A. Patterson and John L. Hennessy, "Computer Organization and
 * Design: The Hardware/Software Interface," Fourth Edition, Morgan
 * Kaufmann, Gurgaon, India, 2009.
 *
 * [Patterson 2009a]
 * David A. Patterson and John L. Hennessy, "Companion CD for Computer
 * Organization and Design: The Hardware/Software Interface [CD-ROM],"
 * Fourth Edition, Morgan Kaufmann, Gurgaon, India, 2009. Available:
 * Companion CD.
 *
 * [Hennessy 2007]
 * John L. Hennessy and David A. Patterson, "Computer Architecture: A
 * Quantitative Approach," Fourth Edition, Morgan Kaufmann, San Francisco,
 * CA, 2007.
 *
 * [Hennessy 2007a]
 * John L. Hennessy and David A. Patterson, "Companion CD for Computer
 * Architecture: A Quantitative Approach [CD-ROM]," Fourth Edition,
 * Morgan Kaufmann, San Francisco, CA, 2007. Available: Companion CD.
 *
 * [Weste 2005]
 * Neil H. E. Weste and David Harris, "CMOS VLSI Design: A Circuits
 * and Systems Perspective," Third Edition, Pearson Education, Boston,
 * MA, 2005.
 *
 * [Rabaey 2003]
 * Jan M. Rabaey, Anantha Chandrakasan, and Borivoje Nikolic, "Digital
 * Integrated Circuits: A Design Perspective," Second Edition, Pearson
 * Education, Upper Saddle River, NJ, 2003.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */




#include "systemc.h"
// Include the interfaces for each SystemC module of the design
#include <iostream>
#include "ipbuffer.h"
#include "addrdecoder.h"
#include "camarray.h"
#include "opbuffer.h"







// Main function of the SystemC design...
int sc_main (int argc, char * argv[]) {
    /**
	 * Declare variables for signals for the following modules:
	 * 1) ipbuffer
	 * 2) addrdecoder
	 * 3) camarray
	 * 4) opbuffer
	 *
	 * The prefix of these signal values shall begin with m,
	 * which indicates a signal declared in the main function,
	 * followed by an abbreviation of the name of the module(s),
	 * and an abbreviation of the type of signal (input, output,
	 * or bidrectional).
	 * If the output of a module is used as the input of another,
	 * use the abbreviation of both modules. This would avoid the
	 * need to create another signal that would receive the value
	 * from another signal when these signals represent the same
	 * wire/bus.
	 */
	// "Encoded" CAM address
	sc_signal<sc_uint<9> > mib_ip_word;
	sc_signal<sc_uint<9> > mibad_oi_word;
	sc_signal<sc_uint<9> > madca_oi_word;
	
	// Comperand
	sc_signal<sc_bv<32> > mib_ip_cpd;
	sc_signal<sc_bv<32> > mibad_oi_cpd;
	sc_signal<sc_bv<32> > madca_oi_cpd;
	
	// Write data
	sc_signal<sc_bv<32> > mib_ip_wr_data;
	sc_signal<sc_bv<32> > mibad_oi_wr_data;
	sc_signal<sc_bv<32> > madca_oi_wr_data;
	
	// Write command
	sc_signal<bool> mib_ip_wr_cmd;
	sc_signal<bool> mibad_oi_wr_cmd;
	sc_signal<bool> madca_oi_wr_cmd;
	
	// Read command
	sc_signal<bool> mib_ip_rd_cmd;
	sc_signal<bool> mibad_oi_rd_cmd;
	sc_signal<bool> madca_oi_rd_cmd;
	
	// Read data
	sc_signal<sc_lv<32> > mcaop_oi_rd_data;
	sc_signal<sc_lv<32> > mop_op_rd_data;
	
	
	// MATCH signal
	sc_signal<bool> mcaop_oi_match;
	sc_signal<bool> mop_op_match;
	
	
	// Create a global clock for the system with a period of 20 ns.
	sc_clock sys_clk("gbl_clk", 20, SC_NS);
	
	
	/**
	 * Instantiate SystemC modules.
	 *
	 * Connect the ports of all the SystemC modules with signals to
	 * create the design of my CAM.
	 */
	ipbuffer ipb("ipbuffer");
	ipb.ip_word(mib_ip_word);
	ipb.ip_cpd(mib_ip_cpd);
	ipb.ip_wr_data(mib_ip_wr_data);
	ipb.ip_wr_cmd(mib_ip_wr_cmd);
	ipb.ip_rd_cmd(mib_ip_rd_cmd);
	ipb.buf_clk(sys_clk);
	ipb.op_word(mibad_oi_word);
	ipb.op_cpd(mibad_oi_cpd);
	ipb.op_wr_data(mibad_oi_wr_data);
	ipb.op_wr_cmd(mibad_oi_wr_cmd);
	ipb.op_rd_cmd(mibad_oi_rd_cmd);
	addrdecoder ad("addrdecoder");
	ad.ip_word(mibad_oi_word);
	ad.ip_cpd(mibad_oi_cpd);
	ad.ip_wr_data(mibad_oi_wr_data);
	ad.ip_wr_cmd(mibad_oi_wr_cmd);
	ad.ip_rd_cmd(mibad_oi_rd_cmd);
	ad.ad_clk(sys_clk);
	ad.op_word(madca_oi_word);
	ad.op_cpd(madca_oi_cpd);
	ad.op_wr_data(madca_oi_wr_data);
	ad.op_wr_cmd(madca_oi_wr_cmd);
	ad.op_rd_cmd(madca_oi_rd_cmd);
	camarray ca("camarray");
	ca.ip_word(madca_oi_word);
	ca.ip_cpd(madca_oi_cpd);
	ca.ip_wr_data(madca_oi_wr_data);
	ca.ip_wr_cmd(madca_oi_wr_cmd);
	ca.ip_rd_cmd(madca_oi_rd_cmd);
	ca.cam_clk(sys_clk);
	ca.op_rd_data(mcaop_oi_rd_data);
	ca.match(mcaop_oi_match);
	opbuffer ob("opbuffer");
	ob.ip_rd_data(mcaop_oi_rd_data);
	ob.in_match(mcaop_oi_match);
	ob.op_clk(sys_clk);
	ob.op_rd_data(mop_op_rd_data);
	ob.out_match(mop_op_match);
	
	
	
	
	
	// Generate some words for the input buffer.
	// Transfer words from the input buffer to the address decoder.
	// Transfer words from the address decoder to the CAM array.
	// Transfer words from the CAM array to the priority encoder.
	// Transfer words from the priority encoder to the output buffer.

	// Print out the words in the output buffer???
	//std::cout << "Hello SystemC! Done.\n";
	//cout << "Hello SystemC! Done. YY" << endl;
	//cout << "sc_get_time_resolution()" << sc_get_time_resolution() << endl;
	// Default time resolution is 1 ps.
	//cout << "sc_get_default_time_unit()" << sc_get_default_time_unit() << endl;
	// Default time unit is 1 ns.
	
    
    
	
	
	
	// Enable SystemC waveform tracing support and create VCD dumps.
	sc_trace_file *tf = sc_create_vcd_trace_file("cam_dump_file");
	// Export the values of the external signals to be traced
	sc_trace(tf, mib_ip_word, "mib_ip_word");
	sc_trace(tf, mibad_oi_word, "mibad_oi_word");
	sc_trace(tf, madca_oi_word, "madca_oi_word");
	sc_trace(tf, mib_ip_cpd, "mib_ip_cpd");
	sc_trace(tf, mibad_oi_cpd, "mibad_oi_cpd");
	sc_trace(tf, madca_oi_cpd, "madca_oi_cpd");
	sc_trace(tf, mib_ip_wr_data, "mib_ip_wr_data");
	sc_trace(tf, mibad_oi_wr_data, "mibad_oi_wr_data");
	sc_trace(tf, madca_oi_wr_data, "madca_oi_wr_data");
	sc_trace(tf, mib_ip_wr_cmd, "mib_ip_wr_cmd");
	sc_trace(tf, mibad_oi_wr_cmd, "mibad_oi_wr_cmd");
	sc_trace(tf, madca_oi_wr_cmd, "madca_oi_wr_cmd");
	sc_trace(tf, mib_ip_rd_cmd, "mib_ip_rd_cmd");
	sc_trace(tf, mibad_oi_rd_cmd, "mibad_oi_rd_cmd");
	sc_trace(tf, madca_oi_rd_cmd, "madca_oi_rd_cmd");
	sc_trace(tf, mcaop_oi_rd_data, "mcaop_oi_rd_data");
	sc_trace(tf, mop_op_rd_data, "mop_op_rd_data");
	sc_trace(tf, mcaop_oi_match, "mcaop_oi_match");
	sc_trace(tf, mop_op_match, "mop_op_match");
	sc_trace(tf, sys_clk, "sys_clk");
	


	

	
	
	sc_initialize();
	// Run the SystemC simulation for 1000 ns.
	sc_start(1000, SC_NS);
	std::cout << "Start simulation...";
	
	// Wait for a 110 ns for data values to settle down
	wait(100, SC_NS);
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060001";
	mib_ip_cpd =		"0x7D30D01";
	mib_ip_wr_data =	"0xF0B0001";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060002";
	mib_ip_cpd =		"0x7D30D02";
	mib_ip_wr_data =	"0xF0B0002";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060003";
	mib_ip_cpd =		"0x7D30D03";
	mib_ip_wr_data =	"0xF0B0003";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060004";
	mib_ip_cpd =		"0x7D30D04";
	mib_ip_wr_data =	"0xF0B0004";
	mib_ip_wr_cmd = true;
	mib_ip_rd_cmd = false;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060005";
	mib_ip_cpd =		"0x7D30D05";
	mib_ip_wr_data =	"0xF0B0005";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060006";
	mib_ip_cpd =		"0x7D30D06";
	mib_ip_wr_data =	"0xF0B0006";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060007";
	mib_ip_cpd =		"0x7D30D07";
	mib_ip_wr_data =	"0xF0B0007";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060008";
	mib_ip_cpd =		"0x7D30D08";
	mib_ip_wr_data =	"0xF0B0008";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE060009";
	mib_ip_cpd =		"0x7D30D09";
	mib_ip_wr_data =	"0xF0B0009";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E001";
	mib_ip_cpd =		"0x7D3ED01";
	mib_ip_wr_data =	"0xF0BE001";
	mib_ip_wr_cmd = true;
	mib_ip_rd_cmd = false;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E002";
	mib_ip_cpd =		"0x7D3ED02";
	mib_ip_wr_data =	"0xF0BE002";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E003";
	mib_ip_cpd =		"0x7D3ED03";
	mib_ip_wr_data =	"0xF0BE003";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E004";
	mib_ip_cpd =		"0x7D3ED04";
	mib_ip_wr_data =	"0xF0BE004";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E005";
	mib_ip_cpd =		"0x7D3ED05";
	mib_ip_wr_data =	"0xF0BE005";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E006";
	mib_ip_cpd =		"0x7D3ED06";
	mib_ip_wr_data =	"0xF0BE006";
	mib_ip_wr_cmd = true;
	mib_ip_rd_cmd = false;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E007";
	mib_ip_cpd =		"0x7D3ED07";
	mib_ip_wr_data =	"0xF0BE007";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E008";
	mib_ip_cpd =		"0x7D3ED08";
	mib_ip_wr_data =	"0xF0BE008";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	// Assign inputs to the CAM
	mib_ip_word =		"0xE06E009";
	mib_ip_cpd =		"0x7D3ED09";
	mib_ip_wr_data =	"0xF0BE009";
	mib_ip_wr_cmd = false;
	mib_ip_rd_cmd = true;
	wait(20, SC_NS);
	
	
	
 
	
	
	
	

	
	
	
	
	
	
	/**
	 * Disable SystemC waveform tracing support.
	 * VCD dump (file) creation is completed.
	 */
	sc_close_vcd_trace_file(tf);
	
	// End of simulation...
    std::cout << "End of simulation..." << std::endl;
	return 0;
}
