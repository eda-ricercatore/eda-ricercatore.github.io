/**
 * An implementation of a content-addressable memory (CAM) at
 * electronic system-level (ESL).
 * 
 * Copyright	(C)	<2010>	<Zhiyang Ong>
 * @author Zhiyang Ong
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *
 *
 * 
 * This is the CAM array.
 * Input	: 9-bit "decoded" address of word to be written
 *			: comparand (32-bit pattern)
 *			: data (32-bit address) to be written into the CAM array
 *			: command to indicate that data should be written into the
 *			  CAM array
 *			: command to indicate that data should be read from the
 *			  CAM array
 *			: system clock
 * Output	: read data of selected word in CAM (after 1 clock cycle)
 *			: MATCH signal (after 1 clock cycle)
 * Function	: Receive inputs at the positive-edge of the clock.
 *			  
 *			  If read command is issued, use the comperand to determine
 *			  if any words in the CAM have data (addresses) that match
 *			  the pattern in the comperand.
 *			  If a match exists, set the MATCH signal to HIGH/TRUE.
 *			  Transfer the data to the output port after half a period.
 *			  Else, keep the MATCH signal to LOW/FALSE.
 *			  
 *			  If write command is issued, write the input data into
 *			  the selected word of the CAM array.
 *			  Set MATCH signal to LOW/FALSE.
 */

// ==================================================================

// Include SystemC Verification Extension to use its scv_random class
//#include <scv.h>
//#include <scv_random.h>
//#include "systemc.h"

SC_MODULE(camarray) {
	// Declaring inputs and outputs
	
	// Input port.
	// Input word ("9-bit encoded" virtual address)
	sc_in<sc_uint<9> > ip_word;
	// Input comperand
	sc_in<sc_bv<32> > ip_cpd;
	// Input write data
	sc_in<sc_bv<32> > ip_wr_data;
	// Input write command
	sc_in<bool> ip_wr_cmd;
	// Input read command
	sc_in<bool> ip_rd_cmd;
	// Input clock
	sc_in_clk cam_clk;
	
	
	// Output port.
	// Output read data
	sc_out<sc_lv<32> > op_rd_data;
	// Output MATCH signal
	sc_out<bool> match;
	
	
	// "Constants"
	
	
	// Declaring instance variables...
	
	/**
	 * Mask used for comparison of the comperand to the words in the
	 * CAM array.
	 * Assume that the pattern is only stored in the first 12 bits.
	 * Use these 12 bits for comparison. Ignore the other bits.
	 */
	sc_bv<32> mask;
	/**
	 * Pattern used for comparing words to it.
	 * It is the result of performing an AND operation on the mask
	 * and the comperand.
	 */
	sc_bv<32> cmp_pattern;
	// Result of comparing the pattern to the currently enumerated word
	sc_bv<32> cmp_result;
	// Storage for the 512-words in the CAM array
	sc_lv<32> arr[512];
	// Largest index of word in CAM where a match is found
	int wd_index;
	
	
	// --------------------------------------------------------------
	
	
	// Declaring functions...
	// Function to write data into the selected word in the CAM array
	void write_data();
	// Function to read data from the matched word in the CAM array
	void read_data();
	// Function to match the comperand with the words in the CAM array
	void match_pattern();
	
	// --------------------------------------------------------------
	
	// Constructor 
	SC_CTOR(camarray) {
		// Populate the contents of the CAM array
		// Seed the random number generator by 1237.
		//void scv_random(1237);
		//void srand(1237);
		/**
		 * For each word in the CAM array, assign it with a randomly
		 * generated number, which represents the physical address in
		 * memory that this TLB CAM refers to.
		 */
		for (int i=0; i<512; i++) {
			// Randomly generate a physical address for this word
			arr[i] = rand();
		}
		
		
		// Method Process
		//SC_CTHREAD(write_data, cam_clk.pos());
		SC_THREAD(write_data);
		// Sensitivity list of the method process
		sensitive_pos(cam_clk);
		sensitive << ip_wr_data;
		sensitive << ip_wr_cmd;
		
		// Method Process
		//SC_CTHREAD(read_data, cam_clk.pos());
		SC_THREAD(read_data);
		// Sensitivity list of the method process
		sensitive_pos << cam_clk;
		sensitive << ip_word;
		sensitive << ip_cpd;
		sensitive << ip_rd_cmd;
		
		// Method Process
		//SC_CTHREAD(match_pattern, cam_clk.pos());
//		SC_METHOD(match_pattern, cam_clk.pos());
		SC_THREAD(match_pattern);
		// Sensitivity list of the method process
		sensitive_pos << cam_clk;
		sensitive << ip_word;
		sensitive << ip_cpd;
	}
};
