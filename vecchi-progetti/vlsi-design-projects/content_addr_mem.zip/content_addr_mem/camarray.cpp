/**
 * An implementation of a content-addressable memory (CAM) at
 * electronic system-level (ESL).
 * 
 * Copyright	(C)	<2010>	<Zhiyang Ong>
 * @author Zhiyang Ong
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *
 *
 *
 * 
 * This is the CAM array.
 * Input	: 9-bit "decoded" address of word to be written
 *			: comparand (32-bit pattern)
 *			: data (32-bit address) to be written into the CAM array
 *			: command to indicate that data should be written into the
 *			  CAM array
 *			: command to indicate that data should be read from the
 *			  CAM array
 *			: system clock
 * Output	: read data of selected word in CAM (after 1 clock cycle)
 *			: MATCH signal (after 1 clock cycle)
 * Function	: Receive inputs at the positive-edge of the clock.
 *			  
 *			  If read command is issued, use the comperand to determine
 *			  if any words in the CAM have data (addresses) that match
 *			  the pattern in the comperand.
 *			  If a match exists, set the MATCH signal to HIGH/TRUE.
 *			  Transfer the data to the output port after half a period.
 *			  Else, keep the MATCH signal to LOW/FALSE.
 *			  
 *			  If write command is issued, write the input data into
 *			  the selected word of the CAM array.
 *			  Set MATCH signal to LOW/FALSE.
 */

// ==================================================================

// Include header files...
//#include "systemc.h"
#include "camarray.h"


/**
 * Function to write data into the selected word in the CAM array
 * If write command is issued, write the input data into the selected
 * word of the CAM array.
 * Set MATCH signal to LOW/FALSE.
 * Since sc_bv only handles 2 values, I cannot set the "read data" to
 * all X's.
 * @param - None
 * @return - Nothing
 */
void camarray::write_data() {
	// Is the write command issued?
	if(ip_wr_cmd) {
		// Write data into bit-vector array
		arr[ip_word.to_uint()] = ip_wr_data;
	}
	
	// No comparison is performed
	match = false;
}
/**
 * Function to read data from the matched word in the CAM array
 * If read command is issued, call match_pattern().
 * If match_pattern() is true, return the word read from the selected
 * address. Set MATCH to TRUE.
 * Else, set MATCH to FALSE.
 * @param - None
 * @return - Nothing
 */
void camarray::read_data() {
	// Is the read command issued?
	if (ip_rd_cmd) {
		// Call match_pattern()
		if (wd_index >= 0) {
			// Read data into bit-vector array
			
			
			/**
			 * Wait for 0.5 clock cycle - to meet setup and hold time
			 * requirements
			 */
			wait(cam_clk->period()/2, SC_NS);
			// Transfer the read data to the outputs
			op_rd_data = arr[wd_index];
			// Match found!
			match = true;
		}else {
			/**
			 * Wait for 0.5 clock cycle - to meet setup and hold time
			 * requirements
			 */
			wait(cam_clk->period()/2, SC_NS);
			// Match not found
			match = false;
		}
	}else {
		/**
		 * Wait for 0.5 clock cycle - to meet setup and hold time
		 * requirements
		 */
		wait(cam_clk->period()/2, SC_NS);
		// Match not found
		match = false;
	}

}
/**
 * Function to match the comperand with the words in the CAM array
 * Perform a logical AND operation on the mask and comperand (input)
 * to obtain the pattern that shall be used for comparisons with words
 * in the CAM array.
 * Enumerate all words in the CAM. For each enumerated word, determine
 * if it matches with the pattern. If it does, store its index until
 * another match can be found. This allows the index of the latest
 * match, which indicates the word with the largest index, to be stored.
 * This is an implementation of the priority encoder in Fig. 12-7 on
 * page 632 of [Rabaey 2003]; see the main.cpp file for the reference
 * of this book. 
 *
 * Set wd_index to be a negative number (e.g., -1) if no match is found.
 * Else, set wd_index as a number bounded within 0 and 511 (inclusive)
 * that represents the index where the word matches with the pattern.
 * If multiple words match the pattern, the largest index is recorded
 * in wd_index.
 * @param - None
 * @return - Nothing
 */
void camarray::match_pattern() {
	// Set the mask to 0xFFF0 0000
	mask = "0xFFF00000";
	// AND the mask and the input pattern
	cmp_pattern = ip_cpd & mask;
	
	// Largest index of word in CAM where a match is found
	wd_index = -1;
	
	// Enumerate all 512 words in the CAM array
	for (int i=1; i<512; i++) {
		// Compare the currently enumerated word with the pattern
		if ((cmp_pattern[31] == arr[31]) && (cmp_pattern[30] == arr[30])
			&& (cmp_pattern[29] == arr[29]) && (cmp_pattern[28] == arr[28])
			&& (cmp_pattern[27] == arr[27]) && (cmp_pattern[26] == arr[26])
			&& (cmp_pattern[25] == arr[25]) && (cmp_pattern[24] == arr[24])
			&& (cmp_pattern[23] == arr[23]) && (cmp_pattern[22] == arr[22])
			&& (cmp_pattern[21] == arr[21]) && (cmp_pattern[20] == arr[20]) ) {
			
			/**
			 * If the most 12 significant bits of the comparison
			 * pattern are the same as those of the currently
			 * enumerated word in the CAM array...
			 * Store the row index of this word in the CAM array.
			 */
			wd_index = i;
		}
	}
	
	// Assert that the index must be < 512
	assert(wd_index < 512);
}