/**
 * This is written by Zhiyang Ong for an interview with Orora Design Technologies
 */

import java.io.*;
import java.lang.*;

// ------------------------------------------

public class Node {

	// Default constructor
	public Node() {
		elem = Integer.MIN_VALUE;
		next = null;
	}

	// Standard constructor
	public Node(int e, Node n) {
		elem = e;
		next = n;
	}
	
	// ------------------------------------------
	
	// Instance variables
	// Next node in the singly linked list
	private Node next;
	// Element in the singly linked list
	private int elem;
	
	// ------------------------------------------
	
	// Method to get the next Node
	public Node get_next() {
		return next;
	}
	
	// Method to get the element
	public int get_elem() {
		return elem;
	}
	
	// ------------------------------------------
	
	// Mutator methods
	
	// Method to modify/update the element
	public void set_elem(int e) {
		elem = e;
	}
	
	// Method to set the next Node
	public void set_next(Node n) {
		next = n;
	}
}