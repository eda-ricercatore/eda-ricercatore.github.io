/**
 * This is written by Zhiyang Ong for an interview with Orora Design Technologies
 */

import java.io.*;
import java.lang.*;
import java.util.*;

// ------------------------------------------

public class Key_Elem_Pair implements Comparator {
	// Constructors

	// Default constructor
	public Key_Elem_Pair() {
		elem = Integer.MIN_VALUE;
		index = Integer.MIN_VALUE;
	}

	// Standard constructor
	public Key_Elem_Pair(int e, int i) {
		elem = e;
		index = i;
	}
	
	// ------------------------------------------
	
	// Instance variables
	
	// Index of this instance of Key_Elem_Pair 
	private int index;
	// Element of this instance of Key_Elem_Pair
	private int elem;
	
	// ------------------------------------------
	
	// Accessor methods
	
	// Method to get the index
	public int get_index() {
		return index;
	}
	
	// Method to get the element
	public int get_elem() {
		return elem;
	}
	
	// ------------------------------------------
	
	// Mutator methods
	
	// Method to modify/update the element
	public void set_elem(int e) {
		elem = e;
	}
	
	// Method to set the index
	public void set_index(int i) {
		index = i;
	}
	
	
	// ------------------------------------------
	
	// Comparison methods
	
	/**
	 * Method to compare two arguments for order
	 * @param o1 is an argument
	 * @param o2 is another argument
	 * @return -1 if o1 < o2, 0 if o1 == o2, or 1 if o1 > o2
	 */
	//public int compare(Key_Elem_Pair o1, Key_Elem_Pair o2) {
	public int compare(Object o1, Object o2) {
//		System.out.println("o1:"+o1.getClass().toString());
//		System.out.println("((Key_Elem_Pair) o1):"+((Key_Elem_Pair) o1).getClass().toString());
		//System.out.println("gE:"+(((Key_Elem_Pair) o1).get_elem()).getClass().toString());
	
		try{
		if(((Key_Elem_Pair) o1).get_elem() < ((Key_Elem_Pair) o2).get_elem()) {
			// o1 < o2
			return -1;
		}else if(((Key_Elem_Pair) o1).get_elem() == ((Key_Elem_Pair) o2).get_elem()) {
			// o1 == o2
			return 0;
		}else{
			// o1 > o2
			return 1;
		}
		}catch(ClassCastException e) {
			return Integer.MIN_VALUE;
		}
	}
	
	
	
	/**
	 * Method to determine if obj is equivalent to this object
	 * @param obj is the object to be compared to
	 * @return TRUE if obj == this object; else, return FALSE
	 */
	public boolean equals(Object obj) {
/*
		if((this.get_elem() == ((Key_Elem_Pair) obj).get_elem())
			&& (this.get_index() == ((Key_Elem_Pair) obj).get_index())) {
*/
		if(this.get_elem() == ((Key_Elem_Pair) obj).get_elem()) {
System.out.println("this.get_elem(): "+ this.get_elem());			
			// obj is equivalent to this object
			return true;
		}else{
			// obj is NOT equivalent to this object
			return false;
		}
	}
}