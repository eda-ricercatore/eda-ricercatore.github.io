/**
 * This is written by Zhiyang Ong for an interview with Orora Design Technologies
 */

// Import appropriate classes and packages from the Java API
import java.io.*;
import java.util.*;
import java.lang.*;
import java.lang.reflect.Array;

// ---------------------------------------------------------

public class question_3 {
	public static void main(String [] args) {
		System.out.println("\n\n\n\n");
		System.out.println("================================================");
		// Create the list of 5 integers
		Node e = new Node(5,null);
		Node d = new Node(4,e);
		Node c = new Node(3,d);
		Node b = new Node(2,c);
		// The heading Node of the singly linked list
		Node a = new Node(1,b);
		
		
		System.out.println("Initial list: 1,2,3,4,5");
		// Call the Node reverse_pairwise(Node head) method
		reverse_pairwise(a);
		
		Node f1 = new Node(6,null);
		Node e1 = new Node(5,f1);
		Node d1 = new Node(4,e1);
		Node c1 = new Node(3,d1);
		Node b1 = new Node(2,c1);
		// The heading Node of the singly linked list
		Node a1 = new Node(1,b1);
		System.out.println("Modified list: 1,2,3,4,5,6");
		// Call the Node reverse_pairwise(Node head) method
		reverse_pairwise(a1);
		
	
	
	
	
		int arr[] = { 15,21,13,47,5};
		// Copy of the same array
		int arr1[] = { 15,21,13,47,5};
		// Sorted into 5,13,15,21,47
		System.out.println("Initial array: 15,21,13,47,5");
		System.out.println("Sorted array: 5,13,15,21,47");
		
		// Determine the ranking of 7 in arr
		System.out.println("a=7; Sorted Position: "+find_ranking(7, arr)+"\n\n\n\n");
		// Determine the ranking of 13 in arr
		System.out.println("a=13; Sorted Position:"+find_ranking(13, arr)+"\n\n\n\n");
		// Determine the ranking of 21 in arr
		System.out.println("a=21; Sorted Position:"+find_ranking(21, arr)+"\n\n\n\n");
								
		// Determine the index table and the rank table of "arr"
		find_ranking2(arr1);
	}

	// ---------------------------------------------------------

	/**
	 * Method to determine the index table and the rank table of "array"
	 *
	 * Assume that the array will be sorted and subsequently be used to
	 * construct the rank and index tables without any modification to
	 * the array. That is, no addition elements can be added to the array,
	 * which can be done using an ArrayList, have elements removed from
	 * it, or have its elements be modified.
	 *
	 * @param array is an integer array of numbers that will be sorted,
	 *	and used to determine its index table and rank table
	 * @return nothing
	 */
	public static void find_ranking2(int[] array) {
		System.out.println("================================================");
		System.out.println("Solution attempt at question 3");
		
		// Create an array of Key_Elem_Pair objects to be sorted
		Key_Elem_Pair[] sort_array = new Key_Elem_Pair[Array.getLength(array)];
		
		// Create an array of integers for the index table of sort_array
		int[] index_table = new int[Array.getLength(array)];
		// Create an array of integers for the rank table of sort_array
		int[] rank_table = new int[Array.getLength(array)];
		// Create an array of integers for the sorted elements of "array"
		int[] sorted = new int[Array.getLength(array)];
	
		// Temporary storage for a Key_Elem_Pair
		Key_Elem_Pair k;
		// Copy elements in "array" into sort_array
		for(int i=0; i<Array.getLength(array); i++) {
			k = new Key_Elem_Pair(array[i],i);
			
			sort_array[i]=k;
		}
		
		
		
		// Enumerate sort_array
		System.out.println("Enumerate sort_array, which is the initial array");
		for(int i=0; i<Array.getLength(array); i++) {
/*
			System.out.print("Element: "+ sort_array[i].get_elem() +"		");
			System.out.println("Index: "+ sort_array[i].get_index());
*/
			System.out.println("Element: "+ sort_array[i].get_elem());
		}
		
		



		// Sort the Key_Elem_Pair objects in the index table by their elements
		Arrays.sort(sort_array, new Key_Elem_Pair());


		System.out.println("Enumerate sorted array of elements");
		for(int i=0; i<Array.getLength(array); i++) {
			System.out.println("Element: "+ sort_array[i].get_elem());
			
			// Construct the index table
			index_table[i] = sort_array[i].get_index();
			// Copy the sorted elements of "array" into sorted
			sorted[i] = sort_array[i].get_elem();
		}

		
		// Construct the rank table
		for(int i=0; i<Array.getLength(array); i++) {
			rank_table[i] = Arrays.binarySearch(sorted, array[i]);
		}
		
		
		
		
		
		// Enumerate the index and rank tables
		System.out.println("Enumerate the index table");
		for(int i=0; i<Array.getLength(array); i++) {
			System.out.println("Index: "+ index_table[i]);
		}
		
		System.out.println("Enumerate the rank table");
		for(int i=0; i<Array.getLength(array); i++) {
			System.out.println("Rank: "+ rank_table[i]);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * Method to the rank of "a" in an array "array"
	 * If "a" is not in "array", return -1 to indicate that "a"
	 * has no rank in "array"
	 * Else, sort the array "array". Determine the index where "a"
	 * can be found
	 */
	public static int find_ranking(int a, int[] array){
		System.out.println("================================================");
		System.out.println("Solution attempt at question 2");
		if(Arrays.binarySearch(array,a) < 0) {
			// ranking of "a" in "array" cannot be determined
			return -1;
		}
		
		// Sort the array
		Arrays.sort(array);
	
		return Arrays.binarySearch(array,a);
	}















	/**
	 * Method to reverse each pair of Nodes in the singly linked list
	 * @precondition head is the leading Node of the list
	 * @postcondition return the new leading Node of the list
	 * @param head is the first Node of the list
	 * @return the new first Node of the list after performing the operation
	 *	to modify the list
	 */
	public static Node reverse_pairwise(Node head) {
		System.out.println("================================================");
		System.out.println("Solution attempt at question 1\n");
		System.out.println("Array prior to modifying the list with...");
		System.out.println("reverse_pairwise (Node* head)");
		
		// Number of elements in the list
		int num_elems=0;
		
		// Print out the contents of the list
		Node temp = head;
		while(temp.get_next() != null) {
			System.out.println(temp.get_elem());
			
			// Enumerate the next available element
			temp = temp.get_next();
			num_elems++;
		}
		System.out.println(temp.get_elem());
		num_elems++;
		
System.out.println("Moving On...");
		
		// Temporary storage variable for swapping
		int temp_swap = 0;
		temp = head;
		while(temp.get_next() != null) {
			// Is this element part of a pair of Nodes that need to be swapped?
			if(((temp.get_next()).get_next() != null) && ((num_elems%2) == 1)) {
				// Yes...
			
				// Make a copy of its current element
				temp_swap = temp.get_elem();
				// Copy the next Node's element into its element
				temp.set_elem((temp.get_next()).get_elem());
				// Move to the next Node
				temp = temp.get_next();
				// Copy the old element of the previous Node into its element
				temp.set_elem(temp_swap);
			
				// Enumerate the next available element
				temp = temp.get_next();
			}else if((temp.get_next() != null) && ((num_elems%2) == 0)) {
				// Yes...
			
				// Make a copy of its current element
				temp_swap = temp.get_elem();
				// Copy the next Node's element into its element
				temp.set_elem((temp.get_next()).get_elem());
				// Move to the next Node
				temp = temp.get_next();
				// Copy the old element of the previous Node into its element
				temp.set_elem(temp_swap);
			
				// Enumerate the next available element
				if(temp.get_next() != null) {
					temp = temp.get_next();
				}
			}
		}
		
		
		
		System.out.println("Array after modifying the list with...");
		System.out.println("reverse_pairwise (Node* head)");
		
		// Print out the contents of the modified list
		temp = head;
		while(temp.get_next() != null) {
			System.out.println(temp.get_elem());
			
			// Enumerate the next available element
			temp = temp.get_next();
		}
		System.out.println(temp.get_elem());
		
		System.out.println("\n\n\n\n\n");

		return new Node();
	}
}











