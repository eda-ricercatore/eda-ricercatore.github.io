#!/usr/bin/ruby -w

=begin
This is written by Zhiyang Ong for his Master's thesis, and partial fulfillment
of his Master of Science program in Electrical Engineering at the University of
Southern California

SYNOPSIS:
process_fac_results.rb

This program processes a list of input text files that contain the results from
the simulation runs. It takes their averages, and fits the appropriate statistical
model on the data

Reference:
http://dev.rubycentral.com/ref/
http://www.ruby-doc.org/docs/ProgrammingRuby/
http://www.ruby-doc.org/stdlib/
http://www.ruby-doc.org/core/

Note that when using block comments, equal-begin ... INSERT_SOMETHING_HERE ...
equal-end, the initial equal-begin tag must at the first column of the current
row/line. The equal-end tag may commence anywhere

Use [cat -n results1.txt | grep "Size of Data Set"] to remove unwanted lines
from the files containing experimental results

IMPORTANT!
The largest value in MATLAB that can be processed is about 1.7976931e+308

Currently, for the list of processes displayed with the UNIX command/process
[top -c e -w -l 1 -o cpu], they are not processed for their measured attibutes
or characteristics, such as %CPU, TIME, FAULTS, PAGEINS, COW_FAULTS, MSGS_SENT,
MSGS_RCVD, BSDSYSCALL, MACHSYSCALL, and CSWITCH
These processes can be processed in the future, if need be

Ruby is dynamically typed; hence, it allows an array to be declared and
initialized with a size of zero, and subsequently have elements of various
types be assigned to it. Note that in statically-typed lnaguages like Java or
C-style languages, all elements in an array must have the same type. However,
in dynamically-typed languages like Ruby, an array can have elements of
different types

Regarding multidimensional arrays:
Printing the contents of multidimensional arrays from the highest dimension
will result in concatenating the printing of elements in lower dimensions.
E.g., in a 2-Dimensional array, the elements in the 2nd dimension for an index
in the first dimension will get concatenated
That is, elements in the 2nd dimension for index i in the first dimension will
be concatenated when the elements in the first dimension are enumerated and
printed

An empty array must be declared and initialized for multidimensional arrays to
be used. Else, an error in interpreting the multidimensional array will occur
at run time

When output is printed to an existing file, it will overwrite that file.
Else, a new file will be created


# cat -n results1.txt | grep "============================================================" | wc -l


convert "vm_stat" to "vmstat",
and "top -c e -w -l 1 -o cpu" to "top -w -l 1 -o cpu"

Commands from MATLAB for basic statistical analysis
max: Smallest elements in array
mean: Average or mean value of array
median: Median value of array
min: Smallest elements in array
mode: Most frequent values in array
std: Standard deviation
var: Variance 

=end

# =============================================================================

class ProcessFile
	# Class variables and constants...
	# List of data set sizes given as input to the toy program, for the
	# factorial function
	@@data_set_sizes=[ 1, 2, 3, 5, 7, 10, 12, 13, 15, 17, 20, 22, 23, 25, 27, 30, 40, 50, 70, 85, 100, 105, 110, 115, 120, 130, 140, 150, 160, 170, 200 ]
	# Number of data set sizes used in the experiment
	NUM_DATA_PTS = @@data_set_sizes.length
	# Array of (the total) execution times for each data set size
	@@execution_times = Array.new(NUM_DATA_PTS)
	# Array of execution times that is allocated to the user for each data set
	# size
	@@exec_usr_times = Array.new(NUM_DATA_PTS)
	# Array of execution times that is allocated to the system for each data
	# set size
	@@exec_sys_times = Array.new(NUM_DATA_PTS)
	
	# Number of times the function mk_sys_calls(), from the Class sys_stats,
	# is called - dependent on (range of data sizes + 1)
	# A constant of 1 is added to account for the initial starting index of
	# [@@num_mk_sys_stats] at index 1, instead of index 0
	@@num_mk_sys_stats = Array.new([0]*(NUM_DATA_PTS+1))
	# Total number of processes present
	@@total_num_proc = Array.new(NUM_DATA_PTS)
	# Total number of processes that are running
	@@total_run_proc = Array.new(NUM_DATA_PTS)
	# Total number of processes that are sleeping
	@@total_sleep_proc = Array.new(NUM_DATA_PTS)
	# Total number of threads running in the aforementioned/these processes
	@@total_num_threads = Array.new(NUM_DATA_PTS)
	# The load average in the last minute, which is defined as the average number
	# of jobs in the run queue in the minute before the process [top] was run
	@@prev_minute_load_avg = Array.new(NUM_DATA_PTS)
	# CPU Usage distribution for user
	@@cpu_usr = Array.new(NUM_DATA_PTS)
	# CPU Usage distribution for system
	@@cpu_sys = Array.new(NUM_DATA_PTS)
	# CPU Usage that is not distributed, and is left idle
	@@cpu_idle = Array.new(NUM_DATA_PTS)
	# Hit rate of the Object cache, as a percentage
	@@obj_cache_hit_rate = Array.new(NUM_DATA_PTS)
=begin
	Average number of faults that caused a page to be copied in per second,
	which is measured in pflt/s
	Note that pflt/s may be negligible, zero or marginally greater than zero,
	if the UNIX process/command [sar -p] is sampled at a time space of 1 million
=end
	@@avg_pflt_s = Array.new(NUM_DATA_PTS)
	
	
	# Name of the output file containing the execution times of this toy program
	@@op_exec_times = File.new("exec_times.txt","w")
	# Name of the output file containing other experimental data for this toy
	# program
	@@op_stats_data = "stats_data"
	# Name of the file extension
	@@file_extn = ".txt"
	
	
	# String used to indicate the end of executing a selected toy program for a
	# data set size
	#TOY_PROG_BAR="============================================================"
	#TOY_PROG_BAR="====================================="
	CTC = "Computational Time Complexity"
	# Current size of the data set
	CUR_SIZE = "Size of Data Set:"
	# Flag to indicate the complete execution of the toy program for a data set
	# size
	REPEAT_PROC = "REPEAT_PROCEDURE"
	# Amount of computational resources dedicated to system processes
	SYS_KEY = "sys"
	# Keyword used to access information regarding processes
	PROCS_KEY = "Processes:"
	# Keyword used to access information regarding the load average
	LOAD_AVG_KEY = "Load Avg:"
	# Keyword used to access information regarding the hit rate of the Object
	# cache, as a percentage
	HIT_RATE_KEY = "Object cache:"
	# Keyword used to access information regarding the average number of faults
	# that caused a page to be copied in per second
	PFLT_S_KEY = "Average:     pgin/s        pflt/s        vflt/s"
	
	
=begin
	There exists a trade-off between [the accuracy of getting basic statistical
	data from executing this Ruby scripting and inheriting some errors in
	rounding off data] and [performing computations of similar accuracy in the
	MATLAB environment and incur the [programming and execution (timewise)] costs]
	of text/information processing
=end
	
	# Index to access the mean of the array
	INDEX_TO_MEAN = 0
	# Index to access the median of the array
	INDEX_TO_MEDIAN = 1
	# Index to access the maximum of the array
	INDEX_TO_MAX = 2
	# Index to access the minimum of the array
	INDEX_TO_MIN = 3
	# Index to access the standard deviation of the array
	INDEX_TO_STANDARD_DEVIATION = 4

# =============================================================================

	# Default constructor for the class ProcessFile
	def initialize()
		# Do nothing!
	end

# =============================================================================

=begin
		Method to verify if a currently desired line in a file is valid
		That is, does this line exist in the file?
		
		Thus, the row number of the current line should be less than the number
		of lines in the input text file
		@precondition [cur_ln] must be less than [file_len]. Else, raise an
			Exception
		@param cur_ln is the line/row number of the current line
		@param file_len is the number of lines in the input text file
=end
	def ProcessFile.verify_cur_ln(cur_ln, file_len)
		if cur_ln >= file_len
			raise "Current indexed line does not reside in this file!!!"
		end
	end

=begin
		Method to process a file containing experimental results from executing
		toy programs
		@precondition must exists as a readable regular file
		@param file_name is the name of the files
=end
	def ProcessFile.analyze_info(file_name)
		# Preconditions...
		
		# Does this file named [file_name] exist as a regular file?
		if !File.file?(file_name)
			# No. Indicate to the user that the filename [file_name] is invalid
			puts "The filename <"+file_name+"> is invalid!!!"
			puts "It does not refer to an existing file."
			return
		end
		
		# Can this file be read?
		if !File.readable?(file_name)
			# No. Indicate to the user that the filename [file_name] is invalid
			puts "The filename <"+file_name+"> is NOT readable!!!"
			return
		end
		
		begin
			# Access and read the file
#			puts "Access and read the file: "+file_name
			# Instance of file being read...
			#f = File.new(file_name, "r")
			f = IO.readlines(file_name)
			# Number of lines in the file
			num_lines = f.length
#puts "num_lines in the file@@@@@@@@@@@@@@@@@@@@@@@@@@@@:::"+num_lines.to_s
			
			# Index to the array of execution times, @@execution_times
			index_et = 0
			
			# cur_ln: Index of current line to be traversed
			# For each line in the file containing experimental results			
			for cur_ln in 0...num_lines
#				puts "f.readlines[cur_ln]"+fr.readlines[cur_ln]
#				puts "[cur_ln]"+f[cur_ln]


				# Does this line indicate the end of executing a toy program?
				if f[cur_ln].include? CUR_SIZE
					# Yes. Verify the size of the data set that has just been found
					temp = f[cur_ln].split
					
					# Assert that the size of the data set found is equal to
					# that being used
					if temp[temp.length - 1].to_i != @@data_set_sizes[index_et]
						puts "Value of @@data_set_sizes[index_et]: "+@@data_set_sizes[index_et].to_s+"<<<"
						puts "Value of temp[temp.length - 1]: "+(temp[temp.length - 1].to_i).to_s+"<<<"
						raise "Mismatch betweenn used & found data set size!!!"
					end
					
					# Go to its next line to access its execution time
					cur_ln += 1
					# Verify that the next line exist
					ProcessFile.verify_cur_ln(cur_ln, num_lines)
					# Access the field containing the execution time...
					temp = f[cur_ln].split
					# And store it
					@@execution_times[index_et]=temp[temp.length - 1].to_f
					
#puts "[cur_ln]"+f[cur_ln]+"########"
					
					# Go to its next line to access the execution time allocated
					# to the user
					cur_ln += 1
					# Verify that the next line exist
					ProcessFile.verify_cur_ln(cur_ln, num_lines)
					# Access the field containing the execution time allocated
					# to the user...
					temp = f[cur_ln].split
					# And store it
					@@exec_usr_times[index_et]=temp[temp.length - 1].to_f
					
					# Go to its next line to access the execution time allocated
					# to the system
					cur_ln += 1
					# Verify that the next line exist
					ProcessFile.verify_cur_ln(cur_ln, num_lines)
					# Access the field containing the execution time allocated
					# to the system...
					temp = f[cur_ln].split
					# And store it
					@@exec_sys_times[index_et]=temp[temp.length - 1].to_f
					
					# Determine the next available execution time...
					index_et += 1

				end
				
=begin
				Does this current line include the pharse [REPEAT_PROC],
				and does its previous line contain [SYS_KEY]?
				
				That is, does it contain "REPEAT_PROCEDURE" and does its
				previous line contain the key word "sys"?
				
				Note that the first iteration does not include calling
				the function sys_stats::mk_sys_calls()
				
				Hence, if this statement belongs to the first interation,
				ignore this statement since the function sys_stats::mk_sys_calls()
				is not called...
				
				### IMPORTANT!!!
				When enumerating multidimensional arrays, do explore lower
				dimensional arrays separately to avoid concatenating their
				contents
=end


				if (f[cur_ln].include? REPEAT_PROC) && (f[cur_ln-1].include? SYS_KEY)
					# For each iteration after the first... enumerate/traverse
					# the lines for processing
					
#puts "[cur_ln]"+f[cur_ln]+"########"

					
					# While its next line exists in this file...
					while ((cur_ln+1) < num_lines)
						# Go to the next line
						cur_ln += 1
						# Verify that this line exists
						ProcessFile.verify_cur_ln(cur_ln, num_lines)
					
						# If this line does not contain [REPEAT_PROC]...
						if !(f[cur_ln].include? REPEAT_PROC)
							# Process information pertinent to the usage of
							# computational resources
							
							# Search for the string [PROCS_KEY] to determine
							# information regarding processes in the computer system
							if (f[cur_ln].include? PROCS_KEY)
								# Obtain the fields regarding processes, and threads
								temp = f[cur_ln].split
								
=begin
								If this element in the array of arrays of
								values for @@total_num_proc is not an array,
								initialize it to be an array
								
								Else, I cannot assign values to this embedded array
								An alternative is to initialize this 2-Dimensional
								array to some default size for all elements in
								each dimension.
=end
								# If this element in the array of higher dimension
								# is NIL, initialize it to an an array
								if @@total_num_proc[index_et] == nil
									@@total_num_proc[index_et] = Array.new
									
									# Since the other parameters of interest
									# have also not been initialized, initialize
									# them to an empty array
									@@total_run_proc[index_et] = Array.new
									@@total_sleep_proc[index_et] = Array.new
									@@total_num_threads[index_et] = Array.new
								end
								
								
								
								# Get the total number of processes present
								@@total_num_proc[index_et][@@num_mk_sys_stats[index_et]] = temp[1].to_i
								# Get the total number of processes that are running
								@@total_run_proc[index_et][@@num_mk_sys_stats[index_et]] = temp[3].to_i
								# Get the total number of processes that are sleeping
								@@total_sleep_proc[index_et][@@num_mk_sys_stats[index_et]] = temp[5].to_i
								# Get the total number of threads running in
								# the aforementioned/these processes
								@@total_num_threads[index_et][@@num_mk_sys_stats[index_et]] = temp[7].to_i
								
							end
							
							# Search for the string [LOAD_AVG_KEY] to determine
							# information regarding the load average of the
							# computer system, and its distribution of CPU usage
							if (f[cur_ln].include? LOAD_AVG_KEY)
								# If this element in the array of higher dimension
								# is NIL, initialize it to an an array
								if @@prev_minute_load_avg[index_et] == nil
									@@prev_minute_load_avg[index_et] = Array.new
									
									# Since the other parameters of interest
									# have also not been initialized, initialize
									# them to an empty array
									@@prev_minute_load_avg[index_et] = Array.new
									@@cpu_usr[index_et] = Array.new
									@@cpu_sys[index_et] = Array.new
									@@cpu_idle[index_et] = Array.new
								end
							
								# Obtain the fields regarding the load average,
								# and threads
								temp = f[cur_ln].split
								
								# Get the total number of processes present
								@@prev_minute_load_avg[index_et][@@num_mk_sys_stats[index_et]] = temp[2].to_f
								# Get the CPU Usage distribution for the user
								@@cpu_usr[index_et][@@num_mk_sys_stats[index_et]] = temp[7].to_f
								# Get the CPU Usage distribution for the user
								@@cpu_sys[index_et][@@num_mk_sys_stats[index_et]] = temp[9].to_f
								# Get the CPU Usage that is not distributed,
								# and is left idle
								@@cpu_idle[index_et][@@num_mk_sys_stats[index_et]] = temp[11].to_f
							end
							
							# Search for the string [HIT_RATE_KEY] to determine
							# the hit rate of the Object cache, as a percentage
							if (f[cur_ln].include? HIT_RATE_KEY)
								# If this element in the array of higher dimension
								# is NIL, initialize it to an an array
								if @@obj_cache_hit_rate[index_et] == nil
									@@obj_cache_hit_rate[index_et] = Array.new
								end
								
								# Obtain the fields regarding the hit rate of
								# the Object cache
								temp = f[cur_ln].split
								# Access the 7th field where the Object cache
								# hit rate
								# ### IMPORTANT!!!
								# Verify the following line to check if the type
								# modification works
								temp=temp[7]
								# Truncate the leading open bracket to obtain
								# the hit rate
								temp=temp[1..temp.length]
								
								# Get the cache hit rate
								@@obj_cache_hit_rate[index_et][@@num_mk_sys_stats[index_et]] = temp.to_i
							end
							
							# Search for the string [PFLT_S_KEY] to determine
							# information regarding the average number of faults
							# that caused a page to be copied in per second
							if !(f[cur_ln].include? PFLT_S_KEY)
								# Go to the next line
								cur_ln += 1
								# Verify that this line exists
								ProcessFile.verify_cur_ln(cur_ln, num_lines)
								
								# If this element in the array of higher dimension
								# is NIL, initialize it to an an array
								if @@avg_pflt_s[index_et] == nil
									@@avg_pflt_s[index_et] = Array.new
								end
								
								# Obtain the fields regarding pflt/s
								temp = f[cur_ln].split

# Debugging Trace
=begin
puts "Length of the temp array: "+temp.length.to_s
puts "Length of the avg_pflt_s[index_et]: "+@@avg_pflt_s[index_et].length.to_s
puts "Length of the avg_pflt_s[index_et][@@num_mk_sys_stats]: "+@@avg_pflt_s[index_et][@@num_mk_sys_stats[index_et]].to_s
=end
								# Get the value for pflt/s
#puts "index_et"+index_et.to_s
#puts "@@num_mk_sys_stats[index_et]"+@@num_mk_sys_stats[index_et].to_s
# Error occurred when index_et==31
								@@avg_pflt_s[index_et][@@num_mk_sys_stats[index_et]] = temp[2].to_f
							end
							
							
							

							
							# Increment the number of times that the function
							# mk_sys_calls() was called
							@@num_mk_sys_stats[index_et] += 1
						end
						# End of executing toy program for current size of the
						# data set
					end
					# Proceed to examine experimental data from the next
					# available execution of the toy program for a larger size
					# of the data set
				end
				
			
				# Enumerate the next available line of text in the input file
				cur_ln += 1
			end
			
			
			# =================================================================
			#
			# End of enumerating each line in the text file containing
			# experimental results...
			#
			# =================================================================
			
			# Print out the sorted experimental data
			ProcessFile.get_statistics()
			
#			puts "MaxTime:::"+MaxTime.to_s
#			puts "NUM_DATA_PTS:::"+NUM_DATA_PTS.to_s

=begin			
			@@execution_times.each{|x| print x, " **&* "}
			puts ""
			@@exec_sys_times.each{|x| print x, " *** "}
			puts ""
			@@exec_usr_times.each{|x| print x, " ***& "}
			puts ""

			puts "Length of @@exec_usr_times: "+@@execution_times.length.to_s
			puts "Length of @@exec_usr_times: "+@@exec_sys_times.length.to_s
			puts "Length of @@exec_usr_times: "+@@exec_usr_times.length.to_s

=end
			# Close the file I/O streams
			# IO stream f is not closed... If I have to, how should I close it?

		rescue EOFError
			$stderr.print "Reached Enf-of-File; no more lines can be read: "+$!
			# Close the file...
			f.close
			raise
		end

		return
	# End of the method: ProcessFile.analyze_info(file_name)
	end
	
	
=begin
	Method to print out the statistical data from the experiments
	For each paramter, or set of parameters, of interest, print out their values
	@return nothing
=end
	def ProcessFile.get_statistics()
		# List the execution times for the toy program: total, user, and system
		for sz in 0...NUM_DATA_PTS
			# Pipe the execution time, and time used by the user and system to
			# the output file created by [@@op_exec_times]
			@@op_exec_times << @@execution_times[sz] << " "
			@@op_exec_times << @@exec_usr_times[sz] << " "
			@@op_exec_times << @@exec_sys_times[sz] << "\n"
			
			
			# Pipe the remaining experimental data to the output file created
			# by [@@op_stats_data]

### COntinue debugging here
			@@op_stats_data << @@total_num_proc[sz].to_s << " "
			@@op_stats_data << "" << " "
			@@op_stats_data << "REPLACE" << " "
		end
		
		# Close the output file streams...
		@@op_exec_times.close
		@@op_stats_data.close

=begin
	@@op_stats_data = "stats_data"
	@@file_extn = ".txt"
	
	# Number of times the function mk_sys_calls(), from the Class sys_stats,
	# is called
	@@num_mk_sys_stats = 0
	# Total number of processes present
	@@total_num_proc = Array.new(NUM_DATA_PTS)
	# Total number of processes that are running
	@@total_run_proc = Array.new(NUM_DATA_PTS)
	# Total number of processes that are sleeping
	@@total_sleep_proc = Array.new(NUM_DATA_PTS)
	# Total number of threads running in the aforementioned/these processes
	@@total_num_threads = Array.new(NUM_DATA_PTS)
	# The load average in the last minute, which is defined as the average number
	# of jobs in the run queue in the minute before the process [top] was run
	@@prev_minute_load_avg = Array.new(NUM_DATA_PTS)
	# CPU Usage distribution for user
	@@cpu_usr = Array.new(NUM_DATA_PTS)
	# CPU Usage distribution for system
	@@cpu_sys = Array.new(NUM_DATA_PTS)
	# CPU Usage that is not distributed, and is left idle
	@@cpu_idle = Array.new(NUM_DATA_PTS)
	# Hit rate of the Object cache, as a percentage
	@@obj_cache_hit_rate = Array.new(NUM_DATA_PTS)
	# Average number of faults that caused a page to be copied in per second,
	# which is measured in pflt/s
	# Note that pflt/s may be negligible, zero or marginally greater than zero,
	# if the UNIX process/command [sar -p] is sampled at a time space of 1 million
	@@avg_pflt_s = Array.new(NUM_DATA_PTS)

=end
	end
	

=begin
Method to determine basic statistical information about data elements in an
array
@param arr is the array of elements
@param len is the size of the array
@return an array containing information regarding the basic statistical
	information about the array of elements. That is, its:
	# mean
	# median
	# maximum
	# minimum
	# estimated standard deviation of the population sample
=end
	def ProcessFile.get_avg(arr, len)
		begin
			if arr.length == 0
				puts "arr is NOT an array@"
			end
		rescue NoMethodError
			puts "arr is NOT an array!"
			res=Array.new
			res[INDEX_TO_MEAN]=arr
			res[INDEX_TO_MEDIAN]=arr
			res[INDEX_TO_MAX]=arr
			res[INDEX_TO_MIN]=arr
			res[INDEX_TO_STANDARD_DEVIATION]=0.0
			return res
		end
	
		sum = 0.0
		for i in 0..(len-1)
			sum = sum + arr[i]
		end
		
		res=Array.new
		res[INDEX_TO_MEAN]=sum/len
		res[INDEX_TO_MEDIAN]=arr[len/2]
		res[INDEX_TO_MAX]=arr.max
		res[INDEX_TO_MIN]=arr.min
		res[INDEX_TO_STANDARD_DEVIATION]=TryClass.get_std_dev(arr, len, res[0])
		
		return res
	end


=begin
Method to determine the standard deviation of data elements in an array
Or rather, it is an estimated standard deviation of the population sample
@param arr is the array of elements
@param len is the size of the array
@param avg is the average value of the data elements in that array
@return the standard deviation of data elements in the array

Reference:
Ronald Christensen, "Analysis of Variance, Design and Regression: Applied
statistical methods", Chapman & Hall, Bungay, Suffolk, UK, 1996, pp. 29
http://en.wikipedia.org/wiki/Standard_deviation
=end
	def ProcessFile.get_std_dev(arr, len, avg)
		begin
			if arr.length == 0
				puts "arr is NOT an array#"
			end
		rescue NoMethodError
			puts "arr is NOT an array!!"
			est_sd = 0.0
			return est_sd
		end
	
		est_std_dev = 0.0
		for i in 0..(len-1)
			est_std_dev = est_std_dev + (arr[i] - avg)**2
		end
		est_std_dev = est_std_dev / (len - 1)
		est_std_dev = sqrt(est_std_dev)
		
		return est_std_dev
	end

end

# =============================================================================

# Beginning of the program...

=begin
	Make amendments here to change the names of input files that will be
	processed
	
	That is, amend the elements/entries of the array [list_of_ip_files]
=end

# List of input files containing the experimental results
list_of_ip_files=["results1.txt","results2.txt","results3.txt","results4.txt"]
list_of_ip_files=list_of_ip_files+["results5.txt","results6.txt","results7.txt"]

# Print the contents of the list to verify if the list is correct
# list_of_ip_files.each{|x| print x, " -- "}
# puts ""


# For each file in the list that is enumerated
ProcessFile.analyze_info("results1.txt")
# leading and lagging