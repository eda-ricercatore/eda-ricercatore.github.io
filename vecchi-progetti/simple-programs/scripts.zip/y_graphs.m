%= Get a set of functions...
% Number of functions
num_func = 17;
% Array of integers forming the base function - O(n)
arr_int = [ 1:20 ];
% Create a list of [num_func] functions...
for i=1:num_func
    %fn(i,:) = [ arr_int.^i.*log10(arr_int) ];
    
    % Create a function specifically for this dimension/index
    fn(i,:) = [ log10(arr_int).^i ];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Index to the first figure...
index_of_fig=1;
% Number of functions (/arrays) traversed...
j=0;
for j=1:num_func
    % For each set of 5 input sizes...
    k=mod(j,5) + 1;
    % Place the respective function into the array of 5
    graph(k,:) = fn(j,:);
    % If 5 input sizes have been processed...
    if k==1
        % Plot the graph for these 5 input sizes
        figure(index_of_fig)
        plot(arr_int,graph(2,:),'r')
        hold on
        plot(arr_int,graph(3,:), 'b-.')
        hold on
        plot(arr_int,graph(4,:), 'g')
        hold on
        plot(arr_int,graph(5,:), '+m')
        hold on
        plot(arr_int,graph(1,:), 'xk')
        hold on
        legend('function 1','function 2','function 3','function 4','function 5');
        temp_title = 'Plot of the current set of 5 functions that are indexed from: ';
        title([ temp_title int2str(j-4) ' to ' int2str(j) ]);
        xlabel('Size of the input, n');
        ylabel('Logarithmic Functions of the i^{th} to (i+4)^{th} order');

        index_of_fig = index_of_fig + 1;
    end
end

% Plot the graph for the remaining functions...
figure(index_of_fig)
for k=2:(mod(j,5)+1)
    switch k
        case 2
            plot(arr_int,graph(k,:),'r')
        case 3
            plot(arr_int,graph(k,:),'-.b')
        case 4
            plot(arr_int,graph(k,:),'xg')
        case 5
            plot(arr_int,graph(k,:),'+m')
        otherwise
            % Since (k==1) should have been processed, this is an error!
            % Also, k<1 and k>5 would also be errors
            error('Number of functions to be processed should be less than 5!')
    end
    
    hold on
    
%line_spec = { 'r' 'b-' 'g' '+m' 'xk' };
    
    
    
    
    
end

% Insert a legend for the suitable amount of functions considered in this graph
switch (mod(j,5)+1)
    case 2
        legend('function 1');
    case 3
        legend('function 1','function 2');
    case 4
        legend('function 1','function 2','function 3');
    case 5
        legend('function 1','function 2','function 3','function 4');
    otherwise
        % Since (j==1) should have been processed, this is an error!
        error('Number of functions to be processed should be less than 5!')
end

% Add the descriptive text labels for this graph... final graph for this
% interval of intermediate sampling...
temp_title = 'Plot of the current set of 5 functions that are indexed from: ';
title([ temp_title int2str(j-(mod(j,5)+1)) ' to ' int2str(j) ]);
xlabel('Size of the input, n');
ylabel([ 'Logarithmic Functions of the i^{th} to (i+' int2str(mod(j,5)) ')^{th} order' ]);



index_of_fig = index_of_fig + 1;
% Plot the graphs for the 1st set of 5 input sizes
figure(index_of_fig)
plot(arr_int,fn(1,:),'r')
hold on
plot(arr_int,fn(2,:), 'b-.')
hold on
plot(arr_int,fn(3,:), 'g')
hold on
plot(arr_int,fn(4,:), '+m')
hold on
plot(arr_int,fn(5,:), 'xk')
hold on
legend('function 1','function 2','function 3','function 4','function 5');
temp_title = 'Plot of the 1st set of 5 functions that are indexed from:';
title([ temp_title '1-5' ]);
xlabel('Size of the input, n');
ylabel('Logarithmic Functions of the 1^{st} to (5)^{th} order');


index_of_fig = index_of_fig + 1;
% Plot the graphs for the 2nd set of 5 input sizes
figure(index_of_fig)
plot(arr_int,fn(6,:),'r')
hold on
plot(arr_int,fn(7,:), 'b-.')
hold on
plot(arr_int,fn(8,:), 'g')
hold on
plot(arr_int,fn(9,:), '+m')
hold on
plot(arr_int,fn(10,:), 'xk')
hold on
legend('function 6','function 7','function 8','function 9','function 10');
temp_title = 'Plot of the 2nd set of 5 functions that are indexed from:';
title([ temp_title '6-10' ]);
xlabel('Size of the input, n');
ylabel('Logarithmic Functions of the 6^{th} to (10)^{th} order');



index_of_fig = index_of_fig + 1;
% Plot the graphs for the 3rd set of 5 input sizes
figure(index_of_fig)
plot(arr_int,fn(11,:),'r')
hold on
plot(arr_int,fn(12,:), 'b-.')
hold on
plot(arr_int,fn(13,:), 'g')
hold on
plot(arr_int,fn(14,:), '+m')
hold on
plot(arr_int,fn(15,:), 'xk')
hold on
legend('function 11','function 12','function 13','function 14','function 15');
temp_title = 'Plot of the 3rd set of 5 functions that are indexed from:';
title([ temp_title '11-15' ]);
xlabel('Size of the input, n');
ylabel('Logarithmic Functions of the 11^{th} to (15)^{th} order');




index_of_fig = index_of_fig + 1;
% Plot the graphs for the 4th set of 5 input sizes
figure(index_of_fig)
plot(arr_int,fn(16,:),'r')
hold on
plot(arr_int,fn(17,:), 'b-.')
hold on
%{
plot(arr_int,fn(18,:), 'g')
hold on
plot(arr_int,fn(19,:), '+m')
hold on
plot(arr_int,fn(20,:), 'xk')
hold on
%}
%legend('function 16','function 17','function 18','function 19','function 20');
legend('function 16','function 17');
temp_title = 'Plot of the 4th set of 5 functions that are indexed from:';
%title([ temp_title '16-20' ]);
title([ temp_title '16-17' ]);
xlabel('Size of the input, n');
%ylabel('Logarithmic Functions of the 16^{th} to (20)^{th} order');
ylabel('Logarithmic Functions of the 16^{th} to (17)^{th} order');




if 3 ~= 5
    disp('Hello World!')
%    error('Print err statement 1')
% Second error statement does not get printed
%    error('Print err statement 2')
end



