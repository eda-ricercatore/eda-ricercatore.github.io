#!/usr/bin/ruby -w

=begin
This is written by Zhiyang Ong for his Master's thesis, and partial fulfillment
of his Master of Science program in Electrical Engineering at the University of
Southern California

SYNOPSIS:
process_fac_results.rb

This program processes a list of input text files that contain the results from
the simulation runs. It takes their averages, and fits the appropriate statistical
model on the data

Reference:
http://dev.rubycentral.com/ref/
http://www.ruby-doc.org/docs/ProgrammingRuby/
http://www.ruby-doc.org/stdlib/
http://www.ruby-doc.org/core/

Note that when using block comments, equal-begin ... INSERT_SOMETHING_HERE ...
equal-end, the initial equal-begin tag must at the first column of the current
row/line. The equal-end tag may commence anywhere

Use [cat -n results1.txt | grep "Size of Data Set"] to remove unwanted lines
from the files containing experimental results

IMPORTANT!
The largest value in MATLAB that can be processed is about 1.7976931e+308

Currently, for the list of processes displayed with the UNIX command/process
[top -c e -w -l 1 -o cpu], they are not processed for their measured attibutes
or characteristics, such as %CPU, TIME, FAULTS, PAGEINS, COW_FAULTS, MSGS_SENT,
MSGS_RCVD, BSDSYSCALL, MACHSYSCALL, and CSWITCH
These processes can be processed in the future, if need be

Ruby is dynamically typed; hence, it allows an array to be declared and
initialized with a size of zero, and subsequently have elements of various
types be assigned to it. Note that in statically-typed lnaguages like Java or
C-style languages, all elements in an array must have the same type. However,
in dynamically-typed languages like Ruby, an array can have elements of
different types

Regarding multidimensional arrays:
Printing the contents of multidimensional arrays from the highest dimension
will result in concatenating the printing of elements in lower dimensions.
E.g., in a 2-Dimensional array, the elements in the 2nd dimension for an index
in the first dimension will get concatenated
That is, elements in the 2nd dimension for index i in the first dimension will
be concatenated when the elements in the first dimension are enumerated and
printed

An empty array must be declared and initialized for multidimensional arrays to
be used. Else, an error in interpreting the multidimensional array will occur
at run time

When output is printed to an existing file, it will overwrite that file.
Else, a new file will be created


# cat -n results1.txt | grep "============================================================" | wc -l


convert "vm_stat" to "vmstat",
and "top -c e -w -l 1 -o cpu" to "top -w -l 1 -o cpu"

Commands from MATLAB for basic statistical analysis
max: Smallest elements in array
mean: Average or mean value of array
median: Median value of array
min: Smallest elements in array
mode: Most frequent values in array
std: Standard deviation
var: Variance 

=end

#include String

# =============================================================================

class ProcessFile
	# Class variables and constants...
	# List of data set sizes given as input to the toy program, for the
	# factorial function
	@@data_set_sizes=[ 1, 2, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300, 400, 500, 600, 700, 800, 850, 900, 950, 1000, 1050, 1100, 1150, 1200, 1250, 1300, 1400, 1500, 1600, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 10000, 50000, 100000, 115000, 120000, 130000, 135000, 1000000 ]
	# Simulation for 10000000 ended abruptly - IS THIS A BUG???
	# Number of data set sizes used in the experiment
	NUM_DATA_PTS = @@data_set_sizes.length
	# Array of (the total) execution times for each data set size
	@@execution_times = Array.new(NUM_DATA_PTS)
	# Array of execution times that is allocated to the user for each data set
	# size
	@@exec_usr_times = Array.new(NUM_DATA_PTS)
	# Array of execution times that is allocated to the system for each data
	# set size
	@@exec_sys_times = Array.new(NUM_DATA_PTS)
	
	# Number of times the function mk_sys_calls(), from the Class sys_stats,
	# is called - dependent on (range of data sizes + 1)
	# A constant of 1 is added to account for the initial starting index of
	# [@@num_mk_sys_stats] at index 1, instead of index 0
	@@num_mk_sys_stats = Array.new([0]*(NUM_DATA_PTS+1))
	# Total number of processes present
	@@total_num_proc = Array.new(NUM_DATA_PTS)
	# Total number of processes that are running
	@@total_run_proc = Array.new(NUM_DATA_PTS)
	# Total number of processes that are sleeping
	@@total_sleep_proc = Array.new(NUM_DATA_PTS)
	# Total number of threads running in the aforementioned/these processes
	@@total_num_threads = Array.new(NUM_DATA_PTS)
	# The load average in the last minute, which is defined as the average number
	# of jobs in the run queue in the minute before the process [top] was run
=begin
LoadAvg     Load  average  over 1, 5, and 15 minutes.  The load average is the average number of jobs in the run queue.
=end
	@@prev_minute_load_avg = Array.new(NUM_DATA_PTS)
	# CPU Usage distribution for user
	@@cpu_usr = Array.new(NUM_DATA_PTS)
	# CPU Usage distribution for system
	@@cpu_sys = Array.new(NUM_DATA_PTS)
	# CPU Usage that is not distributed, and is left idle
	@@cpu_idle = Array.new(NUM_DATA_PTS)
	# Hit rate of the Object cache, as a percentage
	@@obj_cache_hit_rate = Array.new(NUM_DATA_PTS)
=begin
	Average number of faults that caused a page to be copied in per second,
	which is measured in pflt/s
	Note that pflt/s may be negligible, zero or marginally greater than zero,
	if the UNIX process/command [sar -p] is sampled at a time space of 1 million
=end
	@@avg_pflt_s = Array.new(NUM_DATA_PTS)
	@@avg_pagein = Array.new(NUM_DATA_PTS)
	@@avg_vflt_s = Array.new(NUM_DATA_PTS)
	# Instance of input size, where data is sampled
	@@cur_ip_size = Array.new(NUM_DATA_PTS)
	# Number of data samples per input size
	@@num_scores = Array.new(NUM_DATA_PTS)
	
	
	# Name of the output file containing the execution times of this toy program
	@@op_exec_times = File.new("exec_times.txt","w")
	# Name of the output file containing other experimental data for this toy
	# program
#	@@op_stats_data = "stats_data"
	# Name of the file extension
	@@file_extn = ".txt"
@@op_stats_data = File.new("stats_data.txt","w")	
	
	# String used to indicate the end of executing a selected toy program for a
	# data set size
	#TOY_PROG_BAR="============================================================"
	#TOY_PROG_BAR="====================================="
	CTC = "Computational Time Complexity"
	# Current size of the data set
	CUR_SIZE = "Size of Data Set:"
	# Flag to indicate the complete execution of the toy program for a data set
	# size
	REPEAT_PROC = "REPEAT_PROCEDURE"
	# Amount of computational resources dedicated to system processes
	SYS_KEY = "sys"
	# Keyword used to access information regarding averages
	AVERAGE_KEY = "Average:"
	# Keyword used to access information regarding processes
	PROCS_KEY = "Processes:"
	# Keyword used to access information regarding the load average
#	LOAD_AVG_KEY = "Load Avg:"
	LOAD_AVG_KEY = "Load"
	# Keyword used to access information regarding the hit rate of the Object
	# cache, as a percentage
	HIT_RATE_KEY = "Object cache:"
	# Keyword used to access information regarding the average number of faults
	# that caused a page to be copied in per second
#	PFLT_S_KEY = "Average:     pgin/s        pflt/s        vflt/s"
#	PFLT_S_KEY = "Average:     pgin/s        pflt/s        vflt/s"
	PFLT_S_KEY = "vflt/s"
	
	
=begin
	There exists a trade-off between [the accuracy of getting basic statistical
	data from executing this Ruby scripting and inheriting some errors in
	rounding off data] and [performing computations of similar accuracy in the
	MATLAB environment and incur the [programming and execution (timewise)] costs]
	of text/information processing
=end
	
	# Index to access the mean of the array
	INDEX_TO_MEAN = 0
	# Index to access the median of the array
	INDEX_TO_MEDIAN = 1
	# Index to access the maximum of the array
	INDEX_TO_MAX = 2
	# Index to access the minimum of the array
	INDEX_TO_MIN = 3
	# Index to access the standard deviation of the array
	INDEX_TO_STANDARD_DEVIATION = 4

# =============================================================================

	# Default constructor for the class ProcessFile
	def initialize()
		# Do nothing!
	end

# =============================================================================

=begin
		Method to verify if a currently desired line in a file is valid
		That is, does this line exist in the file?
		
		Thus, the row number of the current line should be less than the number
		of lines in the input text file
		@precondition [cur_ln] must be less than [file_len]. Else, raise an
			Exception
		@param cur_ln is the line/row number of the current line
		@param file_len is the number of lines in the input text file
=end
	def ProcessFile.verify_cur_ln(cur_ln, file_len)
		if cur_ln >= file_len
			raise "Current indexed line does not reside in this file!!!"
		end
	end

=begin
		Method to process a file containing experimental results from executing
		toy programs
		@precondition must exists as a readable regular file
		@param file_name is the name of the files
=end
	def ProcessFile.analyze_info(file_name)
		# Preconditions...
		
		# Does this file named [file_name] exist as a regular file?
		if !File.file?(file_name)
			# No. Indicate to the user that the filename [file_name] is invalid
			puts "The filename <"+file_name+"> is invalid!!!"
			puts "It does not refer to an existing file."
			return
		end
		
		# Can this file be read?
		if !File.readable?(file_name)
			# No. Indicate to the user that the filename [file_name] is invalid
			puts "The filename <"+file_name+"> is NOT readable!!!"
			return
		end
		
		begin
			# Access and read the file
#			puts "Access and read the file: "+file_name
			# Instance of file being read...
			#f = File.new(file_name, "r")
			f = IO.readlines(file_name)
			# Number of lines in the file
			num_lines = f.length
#puts "num_lines in the file@@@@@@@@@@@@@@@@@@@@@@@@@@@@:::"+num_lines.to_s
			
			# Index to the array of execution times, @@execution_times
			index_et = 0
			
			# cur_ln: Index of current line to be traversed
			# For each line in the file containing experimental results			
			for cur_ln in 0...num_lines
#				puts "f.readlines[cur_ln]"+fr.readlines[cur_ln]
#				puts "[cur_ln]"+f[cur_ln]


				# Does this line indicate the end of executing a toy program?
				if f[cur_ln].include? CUR_SIZE
					# Yes. Verify the size of the data set that has just been found
					temp = f[cur_ln-9].split
					tempsize=f[cur_ln].split
					
					# Assert that the size of the data set found is equal to
					# that being used
#					if tempsize[tempsize.length - 1].to_i != @@data_set_sizes[index_et]
					if tempsize[tempsize.length - 1].to_i != @@data_set_sizes[index_et]
						puts "Value of @@data_set_sizes[index_et]: "+@@data_set_sizes[index_et].to_s+"<<<"
						puts "Value of temp[temp.length - 1]: "+(temp[temp.length - 1].to_i).to_s+"<<<"
						puts "Value of tempsize[tempsize.length - 1].to_i: "+(tempsize[tempsize.length - 1].to_i).to_s+"<<<"
						raise "Mismatch betweenn used & found data set size!!!"
					end
					
					# And store it - This is the total time
					# My Bash shell script did not capture the total, user, and system execution times
#					@@execution_times[index_et]=temp[temp.length - 1].to_f
initial=7*60*60 + 25*60 + 28

a1=temp[0,1].to_s.to_i
a2=temp[3,4].to_s.to_i
a3=temp[6,7].to_s.to_i

=begin
a1=temp[0,1]
a2=temp[3,4]
a3=temp[6,7]



a1=temp[0,1]
a2=temp[2,3]
a3=temp[4,5]



a1=temp[0,1].to_i
a2=temp[3,4].to_i
a3=temp[6,7].to_i
=end
#current_time_val = (a1.to_i)*60*60 + (a2.to_i)*60 + (a3.to_i)
current_time_val = a1*60*60 + a2*60 + a3
########################
print "IV",initial,":::CT",current_time_val,"\n"
#					@@execution_times[index_et]=temp[0]#.to_f

=begin
puts "Class of current_time_val:::",current_time_val.class
puts "Class of initial:::",initial.class
puts "Class of a1:::",a1.class
puts "Class of a2:::",a2.class
=end
#######@@execution_times[index_et]=(current_time_val - initial)/(@@data_set_sizes[index_et])
@@execution_times[index_et]=current_time_val - initial
					# Determine the next available execution time...
					index_et += 1

				end
				
				# Enumerate the next available line of text in the input file
				cur_ln += 1
			end
			
						
			# Index to the array of execution times, @@execution_times
			index_et = 0
			# Index to the instance of sampled data, @@cur_ip_size
			index_cip = 0
			# cur_line: Index of current line to be traversed
			# For each line in the file containing experimental results
			cur_line=0
			score=0
			while (cur_line <(num_lines-4))
=begin
				Does this current line include the pharse [REPEAT_PROC],
				and does its previous line contain [SYS_KEY]?
				
				That is, does it contain "REPEAT_PROCEDURE" and does its
				previous line contain the key word "sys"?
				
				Note that the first iteration does not include calling
				the function sys_stats::mk_sys_calls()
				
				Hence, if this statement belongs to the first interation,
				ignore this statement since the function sys_stats::mk_sys_calls()
				is not called...
				
				### IMPORTANT!!!
				When enumerating multidimensional arrays, do explore lower
				dimensional arrays separately to avoid concatenating their
				contents
=end

score=0;
				#while(!(f[cur_line].include? REPEAT_PROC) && (f[cur_line-1].include? SYS_KEY))
				while !(f[cur_line].include? REPEAT_PROC)
#####puts cur_line
#puts "CURRENT LINE NUMBER:::",cur_line
#puts "CURRENT LINE:::",f[cur_line]
					if (f[cur_line].include? LOAD_AVG_KEY)
#####################print "LOAD_AVG_KEY:::",f[cur_line],"\n"
						score = score + 1
						load_averages=f[cur_line].split
						@@prev_minute_load_avg[index_cip] = load_averages[2].chop
						@@cpu_usr[index_cip] = load_averages[7].chop
						@@cpu_sys[index_cip] = load_averages[9].chop
						@@cpu_idle[index_cip] = load_averages[11].chop
						
						@@cur_ip_size[index_cip] = @@data_set_sizes[index_et-1]
						
						# Determine the current input size
						@@cur_ip_size
						#index_cip += 1
						
=begin
puts "prev_minute_load_avg:::",@@prev_minute_load_avg[index_et]
puts "cpu_usr:::",@@cpu_usr[index_et]
puts "cpu_sys:::",@@cpu_sys[index_et]
puts "cpu_idle:::",@@cpu_idle[index_et]
=end												
					elsif ((f[cur_line].include? PFLT_S_KEY) && (f[cur_line].include? AVERAGE_KEY))
######################print "PFLT_S_KEY:::",f[cur_line],"\n"
						cur_field1=f[cur_line+1].split
						@@avg_pflt_s[index_cip] = cur_field1[1]
						@@avg_pagein[index_cip] = cur_field1[2]
						@@avg_vflt_s[index_cip] = cur_field1[3]
=begin
puts "avg_pflt_s[",index_et,"]:::",@@avg_pflt_s[index_et].to_s,"<<"
puts "avg_pagein[",index_et,"]:::",@@avg_pagein[index_et].to_s,"<<"
puts "avg_vflt_s[",index_et,"]:::",@@avg_vflt_s[index_et].to_s,"<<"
=end
						#score = score + 1
						index_cip += 1
					end
				
					cur_line += 1
				end
					
				#@@num_scores[index_et]=score
				index_et += 1
				#score=0;
						
				# Enumerate the next available line of text in the input file
				cur_line += 1
			end			
			
			@@num_scores=[ 10, 20, 50, 100, 200, 300, 400, 10, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 ]	
			# =================================================================
			#
			# End of enumerating each line in the text file containing
			# experimental results...
			#
			# =================================================================
			
			# Print out the sorted experimental data
			ProcessFile.get_statistics()
			
#			puts "MaxTime:::"+MaxTime.to_s
#			puts "NUM_DATA_PTS:::"+NUM_DATA_PTS.to_s

=begin			
			@@execution_times.each{|x| print x, " **&* "}
			puts ""
			@@exec_sys_times.each{|x| print x, " *** "}
			puts ""
			@@exec_usr_times.each{|x| print x, " ***& "}
			puts ""

			puts "Length of @@exec_usr_times: "+@@execution_times.length.to_s
			puts "Length of @@exec_usr_times: "+@@exec_sys_times.length.to_s
			puts "Length of @@exec_usr_times: "+@@exec_usr_times.length.to_s

=end
			# Close the file I/O streams
			# IO stream f is not closed... If I have to, how should I close it?

		rescue EOFError
			$stderr.print "Reached Enf-of-File; no more lines can be read: "+$!
			# Close the file...
			f.close
			raise
		end

		return
	# End of the method: ProcessFile.analyze_info(file_name)
	end
	
	
=begin
	Method to print out the statistical data from the experiments
	For each paramter, or set of parameters, of interest, print out their values
	@return nothing
=end
	def ProcessFile.get_statistics()
		# List the execution times for the toy program: total, user, and system
		for sz in 0...NUM_DATA_PTS
			# Pipe the execution time, and time used by the user and system to
			# the output file created by [@@op_exec_times]
			@@op_exec_times << @@data_set_sizes[sz] << " "
			@@op_exec_times << (@@execution_times[sz] - @@num_scores[sz]).abs << "\n"
			#@@op_exec_times << (@@execution_times[sz]/@@num_scores[sz]) << " "
			#@@op_exec_times << @@num_scores[sz] << "\n"
			
		end
			
			
			# Pipe the remaining experimental data to the output file created
			# by [@@op_stats_data]

### COntinue debugging here
		#for sz in 0...(@@cur_ip_size.length-1)
		for sz in 0...(@@cur_ip_size.length)
			#@@op_stats_data << @@data_set_sizes[sz] << " "
			@@op_stats_data << @@cur_ip_size[sz] << " "
			@@op_stats_data << @@prev_minute_load_avg[sz].to_s << " "
			@@op_stats_data << @@cpu_usr[sz].to_s << " "
			@@op_stats_data << @@cpu_sys[sz].to_s << " "
			@@op_stats_data << @@cpu_idle[sz].to_s << " "
			
			
			@@op_stats_data << @@avg_pflt_s[sz].to_s << " "
			@@op_stats_data << @@avg_pagein[sz].to_s << " "
			@@op_stats_data << @@avg_vflt_s[sz].to_s << "\n"
=begin
puts "Value of avg_pflt_s[",sz,"]:::",@@avg_pflt_s[sz].to_s,"<<"
puts "Value of avg_pagein[",sz,"]:::",@@avg_pagein[sz].to_s,"<<"
puts "Value of avg_vflt_s[",sz,"]:::",@@avg_vflt_s[sz].to_s,"<<"
=end
		end
		
		# Close the output file streams...
		@@op_exec_times.close
		@@op_stats_data.close

=begin
	@@op_stats_data = "stats_data"
	@@file_extn = ".txt"
	
	# Number of times the function mk_sys_calls(), from the Class sys_stats,
	# is called
	@@num_mk_sys_stats = 0
	# Total number of processes present
	@@total_num_proc = Array.new(NUM_DATA_PTS)
	# Total number of processes that are running
	@@total_run_proc = Array.new(NUM_DATA_PTS)
	# Total number of processes that are sleeping
	@@total_sleep_proc = Array.new(NUM_DATA_PTS)
	# Total number of threads running in the aforementioned/these processes
	@@total_num_threads = Array.new(NUM_DATA_PTS)
	# The load average in the last minute, which is defined as the average number
	# of jobs in the run queue in the minute before the process [top] was run
	@@prev_minute_load_avg = Array.new(NUM_DATA_PTS)
	# CPU Usage distribution for user
	@@cpu_usr = Array.new(NUM_DATA_PTS)
	# CPU Usage distribution for system
	@@cpu_sys = Array.new(NUM_DATA_PTS)
	# CPU Usage that is not distributed, and is left idle
	@@cpu_idle = Array.new(NUM_DATA_PTS)
	# Hit rate of the Object cache, as a percentage
	@@obj_cache_hit_rate = Array.new(NUM_DATA_PTS)
	# Average number of faults that caused a page to be copied in per second,
	# which is measured in pflt/s
	# Note that pflt/s may be negligible, zero or marginally greater than zero,
	# if the UNIX process/command [sar -p] is sampled at a time space of 1 million
	@@avg_pflt_s = Array.new(NUM_DATA_PTS)

=end
	end
	

=begin
Method to determine basic statistical information about data elements in an
array
@param arr is the array of elements
@param len is the size of the array
@return an array containing information regarding the basic statistical
	information about the array of elements. That is, its:
	# mean
	# median
	# maximum
	# minimum
	# estimated standard deviation of the population sample
=end
	def ProcessFile.get_avg(arr, len)
		begin
			if arr.length == 0
				puts "arr is NOT an array@"
			end
		rescue NoMethodError
			puts "arr is NOT an array!"
			res=Array.new
			res[INDEX_TO_MEAN]=arr
			res[INDEX_TO_MEDIAN]=arr
			res[INDEX_TO_MAX]=arr
			res[INDEX_TO_MIN]=arr
			res[INDEX_TO_STANDARD_DEVIATION]=0.0
			return res
		end
	
		sum = 0.0
		for i in 0..(len-1)
			sum = sum + arr[i]
		end
		
		res=Array.new
		res[INDEX_TO_MEAN]=sum/len
		res[INDEX_TO_MEDIAN]=arr[len/2]
		res[INDEX_TO_MAX]=arr.max
		res[INDEX_TO_MIN]=arr.min
		res[INDEX_TO_STANDARD_DEVIATION]=TryClass.get_std_dev(arr, len, res[0])
		
		return res
	end


=begin
Method to determine the standard deviation of data elements in an array
Or rather, it is an estimated standard deviation of the population sample
@param arr is the array of elements
@param len is the size of the array
@param avg is the average value of the data elements in that array
@return the standard deviation of data elements in the array

Reference:
Ronald Christensen, "Analysis of Variance, Design and Regression: Applied
statistical methods", Chapman & Hall, Bungay, Suffolk, UK, 1996, pp. 29
http://en.wikipedia.org/wiki/Standard_deviation
=end
	def ProcessFile.get_std_dev(arr, len, avg)
		begin
			if arr.length == 0
				puts "arr is NOT an array#"
			end
		rescue NoMethodError
			puts "arr is NOT an array!!"
			est_sd = 0.0
			return est_sd
		end
	
		est_std_dev = 0.0
		for i in 0..(len-1)
			est_std_dev = est_std_dev + (arr[i] - avg)**2
		end
		est_std_dev = est_std_dev / (len - 1)
		est_std_dev = sqrt(est_std_dev)
		
		return est_std_dev
	end

end

# =============================================================================

# Beginning of the program...

# For each file in the list that is enumerated
ProcessFile.analyze_info("res_linear_29jan08.txt")