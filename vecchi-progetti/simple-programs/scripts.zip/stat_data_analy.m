% This is a MATLAB script to plot the simulation results from SKGZO,
% which uses a parameterized statistical model for vertical profiling of
% computer systems
% Author: Zhiyang Ong

% Synopsis:
% stat_data_analy [requires get_complexity]

% Reference: Stephan J. Chapman, "MATLAB Programming for
% Engineers," Brooks/Cole, Toronto, 2000, pp. 289 - 322

% Standard file IDs
% : file id 1 is the standard output device (stdout)
% : file id 2 is the standard error device (stderr)

% Assume that the values for each row are separated by character
% white spaces.
% Use the function [profile] to improve the performance of the script and
% to facilitate the debugging of this script.
% To convert this file into LaTeX format, try this in the Command Window:
% publish('filename','latex')

%{
To publish stuff in LaTeX:
syms x
f = taylor(log(1+x));
latex(f)

syms alpha t
A = [alpha t alpha*t];
latex(A)

H = sym(hilb(3));
latex(H) 
%}

%{
Assume that the script will not have any user interaction. That is, it is
an automated data analysis and graph plotting process.
It will not prompt the user for input, and depends on the user to enter
the correct filenames into the filename variables at the top of the script
If any of the filename variables refers to a nonexistent file, it will terminate
prematurely and avoid processing any data erroneously
Also, assume that the user will modify the number of rows in this file 
In addition, assume that the user will enter information regarding the
sizes of the input data (set) that was used in the experiment
In addition, assume that the filenames containing the mean and median values,
for the acquired parameters of computer system performance, are provided
Next, assume that the list of files for intermediate sampling of the
aforementioned parameters is given... Note that a file exists for each input
size


Since the function [lscov] used for least squares fitting requires the
transposed input matrices to have the same number of rows, it limits the
order of the estimated polynomial is used to fit the function.
Therefore, the number of powers that can be considered is limited by the
number of rows of the transposed input matrices... which is determined by
the number of samples in the experimental data.
Hence, I shall collect samples for more data set sizes for better approximation
of the data's function.

An Aside:
Note that this procedure does not minimize the actual deviations from the
line (which would be measured perpendicular to the given function). In
addition, although the unsquared  sum of distances might seem a more 
appropriate quantity to minimize, use of the absolute value results in
discontinuous derivatives which cannot be treated analytically. The square
deviations from each point are therefore summed, and the resulting residual 
is then minimized to find the best fit line. This procedure results in outlying 
points being given disproportionately large weighting.

Another Aside:
The mean squared error divided by the number of estimated error terms yields
the sum of the squared errors. Therefore, finding the minimum mean squared
errors amount to determining the minimum sum of squared errors

If a statement does not fit on one line, enter three periods (...) , also...
called dots, stops, or an ellipsis, at the end of the line to indicate it continues..
on the next line.
%}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set the precision for the values of the variables in this program
format long g

disp('============================================')
disp('Processing experimental data from an input file...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Replace the filename for the input file HERE!!!
% And, also its number of rows, and the sizes of input used in the
% experiment. In addition, indicate the size of the quanta used to determine
% the period between measurements
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Filename containing the execution times for different input sizes
file_exec = 'exec_times.txt';
% file_exec containing the values of the acquired parameters
file_stats = 'stats_data.txt';
% Input data sizes used; these are the domain values for determining the values
% for the range of polynomials (of various powers)
ip_sz=[ 1 2 5 10 20 30 40 50 60 70 80 90 100 200 300 400 500 600 700 800 850 900 950 1000 1050 1100 1150 1200 1250 1300 1400 1500 1600 2000 3000 4000 5000 6000 7000 8000 10000 50000 100000 115000 120000 130000 135000 1000000 ];
% Length of period in seconds between measurements
period=100;

% Defining "constants" to access the appropriate column in the text files
% containing experimental data...
% Note that in MATLAB, constants do not exist... Hence, these constants are 
% actually variables
% Index to access the input size that was used to sample that instance of data
index_input_size = 1;
% Index to access Load Average of the Previous Minute
index_load_avg = 2;
% Index to access CPU Usage by User
index_cpu_usr = 3;
% Index to access CPU Usage by System
index_cpu_sys = 4;
% Index to access CPU Usage that is Idle
index_cpu_idle = 5;
% Index to access number of pageins per second
index_pagein_per_sec = 6;
% Index to access Average pflt/s
index_avg_pflts = 7;
% Index to access Average vflt/s
index_avg_vflts = 8;


% More definitions
% Character used to create a new line
new_line='\n';
% Number of functions that will be drawn per graph...
num_fn_per_graph=5;

% -------------------------------------------------------------------------------------------------
% File input/ouput operations...
% If this file cannot be opened, prompt the user to select another file
file = exist(file_exec,'file');
if file == 0
    error(['The requested file does not exist: ' file_exec])
elseif file == 2
    disp(['The requested file exists: ' file_exec])
else
    % Return signal value is invalid... Terminate execution of the program,
    % or rather terminate/close MATLAB in this case...
    % I chose to close MATLAB, since I do not know how to terminate a 
    % program
    quit
end


% If this file cannot be opened, prompt the user to select another file
file = exist(file_stats,'file');
if file == 0
    error(['The requested file does not exist: ' file_exec])
elseif file == 2
    disp(['The requested file exists: ' file_exec])
else
    quit
end


% Name of output file
op_file='trends.txt';
% Open a file, and prepare it for writing
f_id = fopen(op_file,'w');

% Determine if  there exists any 
[message,errnum] = ferror(f_id);
if errnum ~= 0
    % Report the existing error!
    error(message);
end

% -------------------------------------------------------------------------------------------------
% Proceed to process the input file...
disp('Proceed to process the input file...')

% Read the results file... get its file ID
fid = fopen(file_exec);
% Read formatted data in the user selected file
[array,count] = fscanf(fid,'%f');
% Number of rows in the input file
[s, numRows] = unix([ 'cat -n '  file_exec ' | wc -l' ]);
numRows=str2num(numRows);
% Determine the number of columns in the input file
numColumns = count / numRows;
% Put the data into the same format as the file
ARR = reshape(array,numColumns,numRows);
array=ARR';

% -------------------------------------------------------------------------------------------------
%{
Determine the range of values for the execution times of the toy programs

Note that the times given for the total execution time, and the times taken by 
the system and process are given with respect to the size of the input
Hence, they are not given in quanta of (input size)/100 for (input sizes>100),
or unity
Therefore, if the input size is greater than 100, subtract 100 seconds from each
reading above 100. Else, subtract n seconds for each reading, where n is the 
current input size
%}

% Get the total execution time for the range of input sizes
for row = 1:numRows
    execution_time(row) = array(row,2);
%{
    if ip_sz(length(ip_sz)) > period
        execution_time(row) = execution_time(row) - ip_sz(row)/period;
    else
        execution_time(row) = execution_time(row) - ip_sz(row);
    end
%}
end


% -------------------------------------------------------------------------------------------------
% Amount of displacement for text (in the graph) indicating its complexity
amt_displacement = -300;

ccs='Computational Complexity for this toy program - total execution time: ';
ccs_t=get_complexity(ip_sz, execution_time,true);
%%%%%%%%%%%%%%%%ccs=[ ccs ccs_t{:,:}(1,:) ];
ccs=[ ccs ccs_t(1,:) ];
%disp([ 'Print-this: ' get_complexity(ip_sz, execution_time)])

% Plot the graph of the total execution time with respect to the input size
figure(1)
%plot(ip_sz,execution_time,'rx')
semilogx(ip_sz,execution_time,'rx')
hold on
legend('total execution time');
%plot(ip_sz,execution_time, 'r', ip_sz,usr_time, 'b-.', ip_sz,sys_time, 'g')
temp_title='\bf Plot of total execution time against input';
temp_title=[ temp_title '\bf size for computational time complexity of O(n)' ];
%title([ temp_title ', without intermediate sampling' ]);
title(temp_title);
xlabel('Size of the input, n');
ylabel('Total execution time (s)');
text((length(ip_sz)/10),amt_displacement,ccs)

% -------------------------------------------------------------------------------------------------
% Plot the graph of the sampled data with respect to the input size

%{
For varying ranges (compare within 10^n), what is the computational complexity
The number six is chosen since it usually covers two orders of magnitude, which
is neither a restrictive nor large range.

Number of data points needed to cover a substantial subrange of input sizes
%}
num_dp=6;


% If there exists a significant number (num_dp) of data points...
if length(ip_sz) > num_dp
    % For each consecutive range of [num_dp] elements...
    for sec_i = 1:(length(ip_sz)-num_dp+1)
        fprintf(f_id,[ 'Val is: ' int2str(ip_sz(sec_i)) '==val of i: ' int2str(sec_i) new_line ]);
        % Process the following for this range of elements...
        %for si = sec_i:(sec_i + num_dp - 1)
        temp=sec_i + num_dp - 1;
        % Determine the computational complexity over this range
        % Only use the user process time for better accuracy
        cc_range='Computational Complexity for this range, from ';
        cc_range=[ cc_range int2str(sec_i) ' to ' int2str(temp) ': ' ];
        % Indicate the computational complexity for this range
        %cc_range=[ cc_range get_complexity(ip_sz(sec_i:(sec_i:temp)),usr_time(sec_i:(sec_i:temp))) ];
        [ cc_t is_log_fn ]=get_complexity(ip_sz(sec_i:temp),execution_time(sec_i:temp),false);
        %cc_range=[ cc_range cc_t ]
        cc_range_n=strcat(cc_range, cc_t);
        %cc_range_n=strcat(cc_range_n, new_line)
        gb=size(cc_range_n);

        cstr=cellstr(cc_range_n);
%{
        if iscell(cstr)
            disp('cstr is a cell')
        end
        if iscellstr(cstr)
            disp('cstr is a cell of strings')
        end

        if iscell(cc_t)
            disp('cc_t is a cell')
        end
        if iscellstr(cc_t)
            disp('cc_t is a cell of strings')
        end
%}
        %fprintf(f_id,'%s\n',cstr);
        %fprintf(f_id,'%s\n',cc_range_n);
        %fprintf(f_id,'%s',cc_range); - This line works!
        %fprintf(f_id,'%s',cc_range_n{1,1}(1,1));
        
%{
Bug Found!

Problem occurs when the computational complexity is O(n*log n)
I do not know if it occurs for O(log n)
%}

%         if sec_i==length(ip_sz)-num_dp+1
%{
        if is_log_fn == true
            fprintf(f_id,'%s\n',cc_range_n(1,:));
        else
            fprintf(f_id,'%s\n',cc_range_n(1,:));
            %fprintf(f_id,'%s\n',cc_t{:,:}(1,:));
        end
%}
        temp_str = [ ' ' cc_range_n(1,:) ];
        % fprintf(f_id,'%s\n',temp_str);
        %fprintf(f_id,'%s\n',sprintf('%s',temp_str));
        fprintf(f_id,'%s\n',char(temp_str));
        

        %fwrite(f_id,cstr,'char')
        %fwrite(f_id,cc_range_n,'char')
        %fwrite(f_id,cc_t,'char')
        %fwrite(f_id,'Hello World','char') - this works!
        % So far, I have only been able to use fwrite with simple strings

        %end
    end
end


% Close the filestream for the input file containing the execution times...
fclose(fid);


%{
Note that the user shall determine if there is a difference in the computational 
complexity over different intervals of input sizes

This is because I would have to perform string/pattern matching to determine 
if the computational complexity of the intervals have changed

Proceed to parse information regarding the acquired parameters from the 
execution of the toy programs...
Since the files containing the average and median parameters for statistical
data analysis have the same number of lines, process them them concurrently.
Hence, I would not have to repeat that same block of code as I enumerate the 
array
%}


% Read the file containing the average values of the parameters... get its file ID
fid_avg = fopen(file_stats);
% Read formatted data in the user selected file
[array_avg,count_avg] = fscanf(fid_avg,'%f');
% Number of rows in the input file
[s_avg, numRows_avg] = unix([ 'cat -n '  file_stats ' | wc -l' ]);
numRows_avg=str2num(numRows_avg);
% Determine the number of columns in the input file
[s_avg, numWords_avg] = unix([ 'cat -n '  file_stats ' | wc -w' ]);
numWords_avg=str2num(numWords_avg);
numColumns_avg = numWords_avg / numRows_avg - 1;
% Put the data into the same format as the file
ARR_avg = reshape(array_avg,numColumns_avg,numRows_avg);
array_avg=ARR_avg';


% Place the elements of each row into an array...
for row = 1:numRows_avg
    % Input size used to sample the data
    input_size_avg(row) = array_avg(row,index_input_size);
    % Load Average of the Previous Minute
    load_avg_avg(row) = array_avg(row,index_load_avg);
    % CPU Usage by User
    cpu_usr_avg(row) = array_avg(row,index_cpu_usr);
    % CPU Usage by System
    cpu_sys_avg(row) = array_avg(row,index_cpu_sys);
    % CPU Usage that is Idle
    cpu_idle_avg(row) = array_avg(row,index_cpu_idle);
    % Number of pageins per second
    pageins_per_sec_avg(row) = array_avg(row,index_pagein_per_sec);
    % Average pflt/s
    avg_pflts_avg(row) = array_avg(row,index_avg_pflts);
    % Average vflt/s
    avg_vflts_avg(row) = array_avg(row,index_avg_vflts);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%{
Plot of the sampled values for the parameters providing information
about: the average load on the system in the previous minute; the 
average number of pageins per second; the average pflt/s; and the
average vflt/s.

[pflt/s] is the number of faults that caused a page to be copied
in per second.
It is used to determine the rate of page faults, and report page
fault activity

[vflt/s] is the number of times the vm_fault routine has been called
per second.
The vm_fault routine is called by the operating system to indicate
that a page needs, or pages need, to be updated with information
needed for the processor to perform its computations
%}
figure(2)
loglog(input_size_avg,load_avg_avg,'xk')
hold on
loglog(input_size_avg,pageins_per_sec_avg, 'bo')
hold on
loglog(input_size_avg,avg_pflts_avg, 'gd')
hold on
loglog(input_size_avg,avg_vflts_avg, '>m')
hold on
legend('Load Average (prev min)','pageins/s','average pflt/s','average vflt/s');
%plot(ip_sz,execution_time, 'r', ip_sz,usr_time, 'b-.', ip_sz,sys_time, 'g')
temp_title='\bf Plot of the sampled values for the average load in the ';
temp_title=[ temp_title '\bf  previous minute, pageins/s, average pflt/s,' ];
temp_title=[ temp_title '\bf and average vflt/s against input' ];
temp_title=[ temp_title '\bf size for computational time complexity of O(n)' ];
%title([ temp_title ', with intermediate sampling' ]);
title(temp_title);
xlabel('Size of the input, n');
ylabel('Load Average (prev min), pageins/s, average pflt/s, and average vflt/s');



%{
Plot of the sampled values for the parameters providing information
about the CPU utilization by the user, system, and idle processes
%}
figure(3)
semilogx(input_size_avg,cpu_usr_avg,'r+')
hold on
semilogx(input_size_avg,cpu_sys_avg,'bd')
hold on
semilogx(input_size_avg,cpu_idle_avg,'go')
hold on
legend('user CPU usage','system CPU usage','idle CPU usage');
%plot(ip_sz,execution_time, 'r', ip_sz,usr_time, 'b-.', ip_sz,sys_time, 'g')
temp_title='\bf Plot of the average values for the percentage of user, system, and';
temp_title=[ temp_title '\bf idle CPU usage' ];
temp_title=[ temp_title '\bf against input size for computational' ];
temp_title=[ temp_title '\bf time complexity of O(n^3), with intermediate sampling' ];
title(temp_title);
xlabel('Size of the input, n');
ylabel('Average values for: percentage of user, system, and idle CPU usage');

% Close the filestream for the input file containing the execution times...
fclose(fid_avg);





% -----------------------------------------------------------------------------
% Detach all file IDs from disk files and devices... Ensure that
% all file streams are closed.
% - make non-standard file IDs invalid
fclose('all');