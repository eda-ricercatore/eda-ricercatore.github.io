% This is a MATLAB script to plot the simulation results from SKGZO,
% which uses a parameterized statistical model for vertical profiling of
% computer systems
% Author: Zhiyang Ong

% Synopsis:
% function [complexity] = get_complexity(ip_size, exec_times)
%
% @param ip_size is the list of input sizes that are used in the experiments
% @param exec_times is the list of execution times for the running the 
% experiments for the corresponding indexed input size
% @param parentheses is a boolean variable indicating if brackets or curly braces
% shall be used; use brackets if value of [parentheses] is true or not defined
% Else, use curly braces
% @return a string indicating the computational complexity of the toy program
% @return a boolean flag indicating if the computational complexity is
% O(n * log n), since it requires special processing by the function caller upon
% the return of the function call

% Assume that the highest power/order for the polynomial describing the
% possible computational time complexity of the toy program is given
% and updated in this program; see [highest_order]
% Estimation for user process and total execution time is given separately
% That is, get_complexity(ip_size, exec_times) should be called separately
% twice

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [complexity, is_log] = get_complexity(ip_size, exec_times,parentheses)
cur_ip_size=ip_size;
cur_exec_times=exec_times;
% Set the precision for the values of the variables in this program
format long g

% -------------------------------------------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% The following paramter [highest_order] needs to be assigned by the user!
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Highest power of polynomials used to fit the experimental data
highest_order=10;

% Set the initial flag [is_log] to false, since the computational complexity
% can be anything but O(n * log n)
is_log=false;

% Definitions of computational time complexity that will be used in the program

% Computational time complexity - O(n^i), where 0<i<highest_order
for pow=1:highest_order
    % Create an array of numbers...
    % Array of values for function described as O(n^i)
    o_n(pow,:) = [ip_size.^(pow)];
    % String representation of the computational complexity; O(n^i)
    if parentheses==false
        gtxt = cellstr(['O(n^[' int2str(pow) '])']);
    else
        gtxt = cellstr(['O(n^{' int2str(pow) '})']);
    end
    comp_n(pow)=gtxt;
end

% Computational time complexity - O(log(n))
o_log_n = [log(ip_size)];
% Computational time complexity - O(n*log(n))
% Determine the range for the function describing O(n*log(n))
o_nlog_n=zeros([1 length(o_log_n)]);
% Assert that the range and domain of the function for O(n*log(n))
if length(ip_size) == length(o_log_n)
    % For each element of the functions for O(n) and O(log n)
    for i=1:length(ip_size)
        % Multiply their i^{th} indices together...
        o_nlog_n(i) = ip_size(i) * o_log_n(i);
    end
else
    error('Vectors x and y should have the same length')
end


% Some other definitions...
% Computational complexity of O(log(n))
comp_logn='O(log n)';
% Computational complexity of O(n*log(n))
comp_nlogn='O(n\cdot log n)';
if parentheses==false
    comp_nlogn='O(n * log n)';
end
% Computational complexity of O(n!)
comp_nfac='O(n!)';
% Domain values for the computational complexity of O(n!)
domain_nfac=[ 1 2 3 5 7 10 12 13 15 17 20 22 23 25 27 30 40 50 70 85 100 105 ];
domain_nfac=[ domain_nfac [ 110 115 120 130 140 150 160 170 200 ] ];
% Range for the function modeling the computational complexity of O(n!)
o_fac_n=[factorial(domain_nfac)];
% Consolidate workspace memory by freeing up needed space by reorganizing 
% information to utilize the minimum memory required.
pack

%{
Standard errors of the least squares fit, or residuals
Standard errors are estimates of the standard deviation
A residual is an observable estimate of the unobservable error.
Errors are often independent of each other; residuals aren't.
%}
stdx=zeros([1,highest_order]);




% -------------------------------------------------------------------------------------------------
% Perform curve fitting on the graphs to determine their computational time complexity

%Try fitting each type of computational complexity to these performance graphs
% For each polynomial of a different power...
for cur_order=1:highest_order
    % Perform least squares fitting on all polynomials from O(n) to
    % O(n^highest_order)
    %
    % x(cur_order): coefficients of the polynomial from the least squares soln.
    % stdx contains the estimated standard errors for each function.
    % mse contains the mean square errors for each function.
    [xs(cur_order),stdxs(cur_order),mses(cur_order)] = lscov(o_n(cur_order,:)',...
        exec_times');
%{
    [xu(cur_order),stdxu(cur_order),mseu(cur_order)] = lscov(o_n(cur_order,:)',...
        usr_time');
%}
end

idx=highest_order+1;
% Try fitting functions with computational complexity fof O(log n), O(n*log n), and O(n!)
[xs(idx),stdxs(idx),mses(idx)] = lscov(o_log_n',exec_times');
%[xu(idx),stdxu(idx),mseu(idx)] = lscov(o_log_n',usr_time');
idx = idx + 1;
[xs(idx),stdxs(idx),mses(idx)] = lscov(o_nlog_n',exec_times');
%[xu(idx),stdxu(idx),mseu(idx)] = lscov(o_nlog_n',usr_time');
idx = idx + 1;
%aq=size(o_fac_n')
%ap=size(domain_nfac')

%{
Determine if the number of data points for execution/user time is greater than
the number of data points for determing if this functional has factorial
computational complexity
%}
if length(o_fac_n) > length(exec_times)
    delta=length(o_fac_n) - length(exec_times) + 1;
    [xs(idx),stdxs(idx),mses(idx)] =...
        lscov(o_fac_n(delta:length(o_fac_n))',exec_times');
%{
    [xu(idx),stdxu(idx),mseu(idx)] =...
        lscov(o_fac_n(delta:length(o_fac_n))',usr_time');
%}
else
    delta=length(exec_times) - length(o_fac_n) + 1;
    [xs(idx),stdxs(idx),mses(idx)] =...
        lscov(o_fac_n',exec_times(delta:length(exec_times))');
%{
    [xu(idx),stdxu(idx),mseu(idx)] =...
        lscov(o_fac_n',usr_time(delta:length(execution_time))');
%}
end


%[xs(idx),stdxs(idx),mses(idx)] = lscov(o_fac_n',execution_time');
%[xu(idx),stdxu(idx),mseu(idx)] = lscov(o_fac_n',usr_time');

%{
For each zero element of [mseu] and [mses], assign it to a large number number,
such as 1e+308
Subsequently, when the minimum of [mses] and [mseu] are sought, the index of the
first zero element will not be returned. This is needed to avoid incorrect 
characterization of the function modeling the computational complexity of the
toy program. Since the toy programs do not specifically behave according to
any of the models for computational complexity, such as O(log n) and O(n!),
the mean squared error cannot be zero. Therefore, all zero elements in [mses]
and [mseu] must be replaced to avoid to avoid such mischaracterization.
Consequently, I have chosen to raise the value of such zero elements to the 
aforementioned large number so that it will not be mistakened as the minimum
mean squared error for the total execution time, or the user/toy program
%}


% Determine the minimum mean squared error among all polynomial
% functions used in this least squares fitting - total execution time
min_mses=min(mses);
% Index to the minimum mean squared error
index_mses=0;
% For each polynomial of a different power, or different function
for index_mses=1:length(mses)
    %disp(['Value of MSE - total execution time: ' int2str(index_mses)])
    % Does this computational complexity have the best fit?
    if mses(index_mses) == min_mses
        disp(['Estimation for total execution time is given as: ' ...
            int2str(index_mses)])
        % Exit the loop when the minimum mean squared error is encountered
        break
    end
end
mses;

%ccs='Computational Complexity for this toy program - total execution time: ';
% Indicate the computational complexity for the toy problem in text format
if (index_mses <= highest_order) && (index_mses>0)
    %ccs=[ccs comp_n(index_mses)];
    complexity=comp_n(index_mses);
elseif index_mses == (highest_order + 1)
    %ccs=[ccs comp_logn];
    complexity=comp_logn;
elseif index_mses == (highest_order + 2)
    %ccs=[ccs comp_nlogn];
    complexity=comp_nlogn;
    is_log=true;
elseif index_mses == (highest_order + 3)
    %ccs=[ccs comp_nfac];
    complexity=comp_nfac;
else
    error('Computational complexity for the toy problem is UNKNOWN!')
end

complexity;
